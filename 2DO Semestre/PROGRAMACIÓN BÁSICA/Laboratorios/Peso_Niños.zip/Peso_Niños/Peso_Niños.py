""" 
   Desarrolle Un Programa En lenguaje de Programación Estructurado que Permita:
    1. Ingresar El Peso Corporal (En Kilogramos) de Tres Niños.
    2. Ingresar El Peso Corporal Promedio Proporcionado Por El Nutricionista.
    3. Determinar, Para Cada Niño, El Tipo de dieta que debe Seguir Según Su Peso En Relación Con El Promedio.
      •	Si El Peso Corporal del Niño Es inferior Al Promedio, Presenta Problemas de Malnutrición Y debe Seguir Una dieta Tipo A.
      •	Si El Peso Corporal del Niño Es igual Al Promedio, Su Peso Está En Estado Óptimo Y debe Seguir Una dieta Tipo B.
      •	Si El Peso Corporal del Niño Es Superior Al Promedio, Presenta Problemas de Obesidad Y debe Seguir Una dieta Tipo C.
    4.	Mostrar En Pantalla:
      - Qué Niño Tiene El Mayor Peso Corporal.
      - Qué Niño Tiene El Menor Peso Corporal.
      - La Suma Total Y El Promedio de los Tres Pesos Corporales ingresados.
     
    Autor: Miguel Ángel Larrea Calle, Samuel Mosquera Palacios, Miguel Ángel Tangarife David 
    Version: 1.0

"""

# Se Procede A Crear Las Funciones.
# Creamos Una Función que le Solicite Al Usuario El Peso Promedio ideal del Niño Y Los Pesos de Tres Niños Promedio. 
# Este También Valida los Valores Numericos Y Mayores que Cero. Y devuelve La Lista de Pesos Y El Peso Promedio.
def Can_Datos(): 
    while True: # Se Crea Un Ciclo While, El Cual Se Repetira hasta que El bloque Se Ejecute Correctamente. 
        try:
            Prom_Peso = float(input("\nIngrese El Peso Promedio del Niño: ")) # Se Le Solicita Al Usuario que ingrese El Peso Promedio del Niño. Esto Recomendado Por El Nutricionista.
            if Prom_Peso <= 0:  # Validamos En Este Caso, que Si El Valor Sea Menor A Cero...
                print("ERROR: El Peso Promedio debe Ser Mayor A 0. Por Favor, Vuelva A intentarlo.") # Se Le Muestra Un Mensaje de ERROR Al Usuario, Si En dado Caso El Valor Numerico del Peso Promedio Haya Sido Menor O igual A Cero.
                continue # Regresamos Al inicio del Ciclo While Para Volver A Pedir El dato.
            
            Psos = []  # Creamos Una Lista donde Se Guardarán los 3 Pesos ingresados.
            
            # Creamos Un Ciclo For que Se Usará Para Pedir El Peso de los 3 Niños Mediante Uno Por Uno.
            for i in range(3):
                while True: # Se Crea Un Ciclo While interno, El Cual Permitirá Repetir El ingresado de Cada Uno de los Pesos (En dado Caso de que Haya Un ERROR) 
                    try: # Se inicia Un bloque de Código Protegido, En El Cual Si Ocurre Un Error, Se Lo Permita Mostrar Y Hacer Saber Al Usuario.
                        PES = float(input(f"Ingrese El Peso del Niño {i + 1}: "))  # Le Solicitamos Al Usuario que ingrese El Peso individual de 3 Niños distintos.
                        if PES <= 0: # Validamos En Este Caso, que Si El Valor Sea Menor A Cero...
                            print("ERROR: El Peso ingresado debe Ser Mayor a 0. Por Favor, intentelo de Nuevo.") # Se Le Muestra Un Mensaje de ERROR Al Usuario, Si En dado Caso El Valor del Peso ingresado Haya Sido Menor O igual A Cero.
                            continue # Regresamos Al inicio del Ciclo While interno (El Cuál, Vuelve A Pedir Ese Mismo Peso)
                        Psos.append(PES)  # Si El dato ingresado Es Válido, Se Procede A Agregar El Valor Al Final de la Lista.
                        break  # Se Procede A Salir del Ciclo interno (Permitiendo ingresar El Valor del Siguiente Niño)
                    except ValueError: # Se Captura El Error que Ocurre Si El Usuario ingresa Un dato que NO Es Un Valor Numérico Tipo int O float.
                        print("ERROR: El dato ingresado No Es Válido. intentelo de nuevo.") # Se Le Muestra Un Mensaje de ERROR Al Usuario, En dado Caso El Valor del Peso ingresado NO Haya Sido Un Valor Numérico Válido.
            break  # Si Se ingresaron Todos los Tres Valores Correctamente, Se Procede A Salir del Ciclo while Principal.  
        except ValueError: # Se Captura El Error que Ocurre Si El Usuario ingresa Un dato que NO Es Un Valor Numérico O Es Un Alfanumérico.
            print("ERROR: El dato ingresado No Es Válido O Es AlfaNumérico. Por Favor, intentelo de Nuevo.") # Se Le Muestra Un Mensaje de ERROR Al Usuario, En dado Caso El Valor del Peso ingresado NO Haya Sido Un Valor Numérico Válido.
    return Psos, Prom_Peso # Finalmente, El Programa Retornará los datos de La Lista (Pesos) Y del Peso Promedio.

# Creamos Otra Función que Calculará La Suma Total Y El Promedio de los Pesos ingresados.
def Cal_Pesos(Psos): 
    Sum_Psos = sum(Psos) # Se Realiza La Suma Total de Todos los Elementos de la Lista.
    PROM = Sum_Psos / 3 # Se Realiza El Promedio, diviendo Por La Cantidad de Elementos de La Lista.
    return Sum_Psos, PROM # Se Retorna La Suma Total Y El Promedio de los Elementos de la Lista que Se Mostrará En Pantalla.

# Creamos Una Última Función que Determinará El Peso Mayor Y El Menor de La Lista.
def Mayor_Y_Menor(Psos):
    P_Mayor = max(Psos) # Se Guarda El Peso Máximo En la Lista.
    P_Menor = min(Psos) # Se Guarda El Peso Minimo En la Lista.
    return P_Mayor, P_Menor # Se Retorna El Peso Máximo Y Mínimo de La Lista que Se Mostrará En Pantalla.

# Se Procede A Crear Los SubProgramas.
# Creamos Un SubPrograma que Permita Clasificar La Cantidad de Pesos Y El Tipo de dieta A Seguir: Malnutrición (Tipo A), Óptimo (Tipo B), Obesidad (Tipo C)
def Tipo_Dieta(Peso_Corp, Peso_PROM):
    Diferencia = Peso_Corp - Peso_PROM # Calculamos La diferencia Entre Ambos Pesos.
    # Aplicamos Una Tolerancia de ±1 KG Para Evitar Errores Por Pequeñas Variaciones.
    if Diferencia < -1: # Si El Peso Corporal del Niño Es inferior Al Promedio... 
        print("→ El Niño Presenta Problemas de Malnutrición, debe Seguir Una dieta Tipo A.") # El Programa Clasificará Y Le Muestra Al Usuario que El Niño Presenta Problemas de Malnutrición Y debe Seguir Una dieta Tipo A.
    elif -1 <= Diferencia <= 1: # Si El Peso Corporal del Niño Es igual Al Promedio...
        print("→ El Niño Presenta Un Peso Óptimo, debe Seguir Una dieta Tipo B.") # El Programa Clasificará Y Le Muestra Al Usuario que El Niño que El Niño Presenta Un Peso Óptimo Y debe Seguir Una dieta Tipo B.
    else: # Si El Peso Corporal del Niño Es Superior Al Promedio... 
        print("→ El Niño Presenta Problemas de Obesidad, Seguir dieta Tipo C.") # El Programa Clasificará Y Le Muestra Al Usuario que El Niño que El Niño Presenta Problemas de Obesidad Y debe Seguir Una dieta Tipo C.

# Creamos Otro SubPrograma que Mostrará Los Cálculos Generales de La Suma Total Y El Promedio de los Tres Pesos ingresados.
def Ver_Psos(Sum_Psos, PROM):
    print("La Suma Total de los Pesos ingresados Es: ", round(Sum_Psos, 2)) # Se Le Muestra En Pantalla La Suma Total de los Tres Pesos ingresados Al Usuario.
    print("El Promedio de los Pesos ingresados Es: ", round(PROM, 2)) # Se Le Muestra En Pantalla El Promedio de los Tres Pesos ingresados Al Usuario.

# Se Procede Al Programa Principal
if __name__ == '__main__': # Verificamos Si El Archivo Se Está Ejecutando Correctamente.
    while True: # Se Crea Un Ciclo While, El Cual Se Permitirá Repetir Todo El Proceso Si El Usuario desea Continuar. 
        
        # Se Procede A Llamar A Todas Las Funciones Y SubProgramas.
        # --- Entrada de datos ---
        Psos, Prom_Peso = Can_Datos()

        # --- Cálculos ---
        Sum_Psos, PROM = Cal_Pesos(Psos)
        P_Mayor, P_Menor = Mayor_Y_Menor(Psos)
        print("El Peso Mayor Es:", P_Mayor) # Se Le Muestra Al Usuario El Peso Mayor En la Lista.
        print("El Peso Menor Es:", P_Menor) # Se Le Muestra Al Usuario El Peso Menor En la Lista.

        # --- Resultados Generales ---
        Ver_Psos(Sum_Psos, PROM)

        # --- Evaluación individual de Cada Niño ---
        print("\n===== EVALUACIÓN INDIVIDUAL =====")
        
        # Creamos Un Ciclo For que Se Usará Para Recorrer La Lista Pesos Usando El Comando Enumerate Y Por Medio de devolver dos Valores: El índice (i) Y El Peso del Niño.
        for i, Peso in enumerate(Psos):
            print(f"\nNiño {i + 1}: Peso = {Peso} kg")  # Se Le Muestra Al Usuario El Respectivo Número Y El Peso del Niño.
            Tipo_Dieta(Peso, Prom_Peso) 

        # --- Preguntar Al Usuario Si desea Repetir ---
        while True:  # Creamos Un Ciclo interno Para Validar la Respuesta del Usuario.
            # Se Le hace decidir Al Usuario Si desea Continuar O Terminar El Programa.
            Option = input("\nEl Resultado Ha Sido impreso, ¿Desea Repetir Otra Evaluación? (Si/No): ").lower()
            
            if Option == 'si':
                print("\nReiniciando El Programa...\n")
                break  # Rompe el ciclo interno y reinicia el programa
            # Si El Usuario decide Terminar, Mediante Cualquier Combinación de Mayusculas Y Minusculas...
            elif Option == 'no':
                # Se Le hace Mostrar Al Usuario Un Mensaje de despedida.
                print("\nPrograma Terminado. ¡Hasta luego! 😊")
                exit()  # Se Finalizam El Programa.
                # Si El Usuario No decide de la Manera Correcta Y debida, Esto Por Medio de Letras O Numeros.
            else:
                # Se Le hace Mostrar Al Usuario Un Mensaje de Error, indicando que Su Opción Es incorrecta Y que debe Volver A decidir.
                print(" ERROR: La Opción que ha ingresado No Es Válida. Solo Se Permite decidir Entre Si O No. intentelo de Nuevo.")





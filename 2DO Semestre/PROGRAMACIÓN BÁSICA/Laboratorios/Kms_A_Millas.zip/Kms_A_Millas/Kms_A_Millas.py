
"""
    Desarrollar Un Programa que Convierta Kilómetros A Millas
    Autor: Miguel Ángel Larrea Calle, Samuel Mosquera Palacios, Miguel Ángel Tangarife David 
    Version: 1.0
"""
# Se Crea La Función Para Convertir Los Kilómetros ingresados Por El Usuario.
def Kms_A_Millas(kms): 
    mills = kms * 0.621371 # Se da La fórmula Para Convertir Kilómetros A Millas.
    return mills # Se Retorna La Cantidad de Millas que Se Mostrará En Pantalla.

# Se Crea Un SubPrograma que Permita Clasificar La Cantidad de distancias: Corta, Mediana Y Larga.
def Class_Distancias(mills):
    if mills < 20: # Si La Cantidad de Millas Es Menor de 20, El Programa Clasificará inmediatamente Como Pequeña distancia.
           print("Es Considerado Pequeña distancia")   
    elif mills >= 20 and mills <= 100: # Si La Cantidad de Millas Son de 20 A 100, El Programa Lo Clasificará Como Mediana distancia.
           print("Es Considerado distancia Media")
    else: # Si El Valor de Millas No Cumple Ninguno de Los Criterios Anteriores (El Valor Es Mayor que 100) El Programa Lo clasificará Como Larga distancia. 
           print("Es Considerado Larga distancia")

# Se Crea Otro SubPrograma Específico Para Mostrarle La Cantidad de Millas Al Usuario.        
def Ver_Millas(mills):
    print("La Cantidad de Millas Es:", round (mills,2)) # Se Le Muestra En Pantalla La Cantidad Total de Millas Al Usuario.


# Asegurar que El Código dentro del bloque Solamente Sea Ejecutado Y No Sea importado Como Otro Módulo (Si Se Corre directamente El Archivo)
if __name__  == "__main__":
     
   # Se Genera Una Bucle infinitivo Para ingresar Varias Kilómetros, Hasta que El Usuario decida Terminar.
    while True:
       entrada = input("Ingresa La Cantidad de kilometros: ") # Se Le Solicita Al Usuario que ingrese La Cantidad de Kilómetros que desea Convertir A Millas.
      
   # Se Valida Un Mensaje de Texto Para que El Usuario decida Salir O Terminar El Programa.
       if entrada.lower() in ["salir", "terminar"]:
          print("Programa Terminado") # Se Aprueba La Solicitud del Usuario de Finalizar El Programa.
          break # El Bucle Es destruido, Y El Programa Finaliza.
    
    
       try:
   # Se Genera Un Valor de Entrada Tipo décimal
          kms= float(entrada)
   # En Caso de Un dato Alfanumérico, Numero Negativo O invalido, Se Le Solicita Al Usuario que ingrese Los Datos Validos Y Unicamente deseados.
       except ValueError:
          print("Ingresar Número Valido O Escribir (Salir O Terminar)")
          continue # El Ciclo Se Reinicia Y Continua.
   # Se Valida que El dato No Sea Menor O igual A Cero. Y Se Notifica Al Usuario que El dato que Esta Solicitando No Es Valido.
       if kms <= 0:
           print("ERROR, El dato ingresado No Es Válido, Vuelva A intentarlo O Solicite La Opción (Salir O Terminar)")
           continue #El Ciclo Se Reinicia Y Continua.
       
   # Se decide Llamar A La Función Y Los SubProgramas Para Finalizar El Algoritmo.
       mills = Kms_A_Millas(kms)
       Class_Distancias(mills)
       Ver_Millas(mills)
    
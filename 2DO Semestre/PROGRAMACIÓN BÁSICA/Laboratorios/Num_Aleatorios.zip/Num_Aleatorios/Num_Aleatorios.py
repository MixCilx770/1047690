""" 
    Programa que Permite ingresar Cuatro Números Enteros Aleatoriamente, Y Muestra Cuantos Y Cuales Números Son Positivos Y Negativos, Mediante la Muestra de la Suma Y Promedio de los Cuatro Números ingresados Aleatoriamente. Y Adicionalmente, Mostrando El Valor Máximo Y Mínimo de Los Números.
    Versión: 1.0
    Autor: Miguel Angel Larrea Calle, Samuel Mosquera Palacios, Miguel Angel Tangarife David
"""

# Se Procede A Crear Las Funciones
def Prom_Num(numeros): # Se Crea la Funcion Promedio que Realiza El Calculo de los 4 Numeros Y devolvera Su Promedio.
    return sum(numeros) / len(numeros) # Se Realiza La Suma de Todos los Elementos de la Lista Y devuelve la Cantidad de Elementos En la Lista.

def Suma_Num(numeros): # Se Crea Otra Funcion que Sumara Los 4 Numeros Y devolvera la Respectiva Suma de Estos.
    return sum(numeros) # Se Procede A devolver La Suma de Todos los Elementos de la Lista.

# Se Procede A Crear Los SubProgramas
def Mayor_O_Menor(numeros): # Se Crea Un SubPrograma que Al Llamarlo En El Programa Principal Nos dara El Valor del Numero Mayor Y El Menor.
      print("El Numero Mayor Es:", max(numeros)) # Se devuelve El Valor Máximo En la Lista.
      print("El Numero Menor Es:", min(numeros)) # Se devuelve El Valor Mínimo En la Lista.


def Defi_Num(numeros): # Se Crea Otro SubPrograma que Nos Organizara los Numeros ingresados Por El Usuario En la Lista de Positivos Y Negativos. 
    Positivos =[] # Se Crea Una Lista Vacía Para Guardar Los Números Positivos.
    Negativos =[] # Se Crea Una Lista Vacía Para Guardar Los Números Negativos.
    
    
    for n in numeros: # Se Procede A Recorrer Cada Elemento de la Lista "Numeros", Uno Por Uno, Mientras que (n) Toma Uno Por Uno los Valores de la Lista Numeros.
        if n > 0: # Se Comprueba Si El Número Actual (n) Es Mayor que 0.
            Positivos.append(n) # Se Procede A Agregar El Número (n) Al Final de la Lista "Positivos".
        elif n < 0: # Se Comprueba Si El Número Actual (n) Es Menor que 0, Es decir, que Es Negativo.
            Negativos.append(n) # Se Procede A Agregar El Número (n) Al Final de la Lista "Negativos".
        
            
    print("Los Numeros Positivos Son:", Positivos, "Cantidad:", len(Positivos))# Se le devuelve Al Usuario, la Cantidad de Elementos En la Lista "Positivos".
    print("Los Numeros Negativos Son:", Negativos, "Cantidad", len(Negativos)) # Se le devuelve Al Usuario, la Cantidad de Elementos En la Lista "Negativos".

# Se Procede Al Programa Principal
if __name__ == '__main__':# Se Nos Verifica Si El Archivo Se Está Ejecutando directamente Como Programa Principal.
    
    while True:# Se Crea Un Ciclo que Permite Repetir Todo El Programa hasta que El Usuario decida Salir.
    
     Nums = [] # Se Crea Una Lista Vacía para Almacenar los 4 Números ingresados Por El Usuario.
     for i in range(4): # Bucle que Se Repite 4 Veces Para Pedir 4 Números.
        while True: # Ciclo que Valida que El Usuario ingrese Un Número Entero Válido.
          try: # Se inicia Un bloque de Código Protegido, En El Cual Si Ocurre Un Error, Se Lo Permita Mostrar Y Hacer Saber Al Usuario.
            Num = int(input("Ingrese Los Numeros: " + str(i +1)+ ":")) # Se Construye El Mensaje Para Mostrar, indicando El Número de la iteración, Mediante que Se Convierte El índice "i" A Texto, Para Mostrarlo: 1,2,3,4.
            break # Si Se ingresa Un Número Válido, Se Procede A Salir del Ciclo While.
          except ValueError: # Se Captura El Error que Ocurre Si El Usuario ingresa Un dato que NO Es Un Número Entero.
              print("ERROR: Ingrese Un Numero Entero Valido") # Se le Muestra Al Usuario Un mensaje Para que ingrese Un dato Valido Numerico Entero.
        Nums.append(Num) # Se Permite que cada Vez que El Usuario ingresa Un Número Válido, Se Guarde En la Respectiva Lista de Numeros.
        
# Se Procede A LLamar A Cada Una de Las Funciones Y SubProgramas.
     Defi_Num(Nums) # Se llama Al 1Er SubPrograma Para definir los Numeros que Son Positivos Y Negativos, Pasando los valores Almacenados En la Respectiva Variable "Numeros".
     Suma= Suma_Num(Nums) # Se llama A La 1ra Funcion Para Sumar los 4 Numeros ingresados Por El Usuario, Pasando los valores Almacenados En la Respectiva Variable "Numeros".
     print("La Suma de los Numeros Es:", Suma) # Se Procede A Mostrar Al Usuario, La Muestra del Valor de la Suma de los Numeros ingresados.
     Mayor_O_Menor(Nums) # Se llama Al 2do SubPrograma, Mediante que Nos dira Cual Es El Numero Mayor Y El Menor, Pasando los Valores de la Variable "Numeros".
     Prom= Prom_Num(Nums) # Se llama A La 2da Función, Para Calcular El Promedio de los Numeros ingresados, Pasandole los datos Almacenados En la Variable. 
     print("El Promedio de los Numeros Es:", Prom) # Se le Muestra Al Usuario El Valor del Promedio de los Numeros ingresados
     
     Opcion = input("¿Desea Salir del Programa? (Si/No): ").lower() # Se Le Hace decidir Al Usuario Si desea Continuar Usando El Programa.
     if Opcion == "si": # Si El Usuario Escribe "Si", Mediante Cualquier Combinación de Mayusculas Y Minusculas.
        print("Programa Terminado, Hasta luego") # Se Muestra Al Usuario Un Mensaje de despedida.
        break # Si El Usuario Respondió Si, Se Termina El Ciclo Y Finaliza El Programa.
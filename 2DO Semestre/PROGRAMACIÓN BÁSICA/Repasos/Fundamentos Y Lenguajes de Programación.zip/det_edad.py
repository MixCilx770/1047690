# Programa que calcula la edad de una persona conocido el año de nacimiento y determina el estado de esta frente a la edad.
# Version: 1.0
# Autor: Jose Alirio Barragan Sanchez


def Calcular_edad(AC, an):
    edad = AA - an
    return edad

def determinar_est(ME,an,edad):
    print("El año de nacimiento ingresado es:",an, " años")
    print("La edad calculada es:",edad)
    if edad == ME:
        mensaje = "Esta en la mayoria de edad"
    else:
        if edad > ME:
            mensaje = "Es mayor de edad"
        else:
            mensaje = "Es menor de edad"
    print("Se determino que usted ",mensaje)


if __name__ == '__main__':
    AA = int() # Constante para el valor del año actual
    E = int() # Constante que almacena la mayoria de edad (18)
    an = int() # Variable que almacena el año de nacimiento
    edad = int()
    mensaje = str()
    AA = 2023
    ME = 18
    print("Cual es su año de naciemiento ?")
    an = int(input())
    edad = Calcular_edad(int(AA), int(an))
    determinar_est(int(ME), int(an), int(edad))
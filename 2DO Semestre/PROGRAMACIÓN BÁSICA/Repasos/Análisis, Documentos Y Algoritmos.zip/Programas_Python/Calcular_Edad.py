"""
    programa que calcula la edad conocido el año de nacimiento de una persona
    Autor: Jose Alirio Barragan Sanchez
    Version: 1.0
"""

def calculo_edad(AA, an):
    edad = int()
    edad = AA - an
    return edad

def estado_edad(ME, edad):
    mensajee = str()
    if edad == ME:
        mensajee = "Esta en la mayoria de edad: "
    else:
        if edad > ME:
            mensajee = "Es mayor de edad"
        else:
            mensajee = "Es menor de edad"
    return mensajee

def documento_derech(edad):
    mensajed = str()
    if edad >= 0 and edad <=7:
        mensajed = "Debe tramitar REGISTRO CIVIL"
    else:
        if edad > 7 and edad <=17:
            mensajed = "Debe tramitar TARJETA DE IDENTIDAD"
        else:
            mensajed = "Debe tramitar CEDULA"
    return mensajed

if __name__ == "__main__":
    AA = int()
    ME = int()
    an = int()
    edad = int()
    mensajee = str()
    mensajed = str()
    valid = bool()
    AA = 2024
    ME = 18
    valid = False
    an = 0
    while an < 1904 or an > 2024:
        valid = False
        while valid == False:
            try:
                print("Ingrese el año de nacimiento de la persona: ")
                an = int(input())
                valid = True
            except:
                print("ERROR: Ingreso alfanumerico para el año de nacimiento, se espera valores enteros")
                valid = False
        if an < 1904 or an > 2024:
            print("ERROR: El año de nacimiento no puede ser inferior a 1904, ni superior a 2024")
    edad = calculo_edad(AA, an)
    mensajee = estado_edad(ME, edad)
    mensajed = documento_derech(edad)
    print("El año de nacimiento ingresado es: ",an)
    print("La edad calculada es: ",edad, " años")
    print("El estado es: ",mensajee)
    print("El tipo de documento: ", mensajed)





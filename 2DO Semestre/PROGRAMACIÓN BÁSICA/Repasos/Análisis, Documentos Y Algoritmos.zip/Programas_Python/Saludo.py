""" 
    Hacer un programa que solicite al usuario el nombre y 
    envie un mensaje de saludo por pantalla con el nombre del usuario.
    Version: 1.0
    Autor: Jose Alirio Barragan Sanchez
"""

def Ingresar_nombre(): # Se define la funcion que le solicita al usuario el nombre y lo retorna al programa princiapal.
    nombre = str() # Se define nombre como variable de tipo cadena.
    print("Ingrese su nombre: ") # Envio mensaje al usuario solicitandole que ingrese el nombre
    nombre = input() # Se lee el nombre ingresado por usuario y se almacena en la variable nmbre
    return nombre # Se retorna el nombre leido al programa principal.

def Mostrar_mensaje_nombre(nombre):
    mensaje = str()
    mensaje = "Bienvenido a Programacion Basica, " + nombre
    print(mensaje)

if __name__ == "__main__":
    nombre = str()
    nombre = Ingresar_nombre()
    Mostrar_mensaje_nombre(nombre)





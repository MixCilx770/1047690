
# Hacer un programa que le permita a un usuario ingresar un grupo de numeros enteros, almacenarlos en una matriz de nxm y  mostrarlos.
# El numero de filas n, lo ingresa el usuario, lo mismo que el numero de columnas m.
# Autor: Jose Alirio Barragan Sanchez
# Version: 1.0
def leer_nfil_mcol():
	n = int()
	m = int()
	print("Ingrese la cantidad de filas: ")
	n = int(input())
	print("Ingrese el numero de columnas: ")
	m = int(input())
	return n,m

def leer_matriz_ent(matn, n, m):
	f = int()
	c = int()
	print("A continuacion ingrese uno a uno los valores enteros a almacenar en la matriz de ",n," Filas y ",m," Columnas: ")
	for f in range(n):
		for c in range(m):
			print("Valor de la Fila ",f," y Columna ",c," => ")
			matn[f][c] = int(input())

def mostrar_matriz_ent(matn, n, m):
	f = int()
	c = int()
	print("Los valores almacenados en la matriz de ",n," Filas y ",m," Columnas son: ")
	for f in range(n):		
		for c in range(m):
			print("Valor de la Fila ",f," y Columna ",c," => ")
			print(matn[f][c])

if __name__ == '__main__':
	n = int()
	m = int()
	i = int()
	j = int()
	matn = []
	n,m = leer_nfil_mcol()
	for i in range(n):
		matn.append([0]*m) 
	leer_matriz_ent(matn,n,m)
	mostrar_matriz_ent(matn,n,m)
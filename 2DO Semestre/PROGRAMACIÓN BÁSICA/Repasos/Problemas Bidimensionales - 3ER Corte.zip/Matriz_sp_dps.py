
# Programa que permita almacenar en una matriz cuadrada de N filas y columnas numeros reales y calcule y muestre la suma y el promedio de los elementos de su diagonal principal y diagonal secundaria.
# Autor: José Alirio Barragán Sánchez
# Versión: 1.0
def leer_cant_fc():
	n = int()
	print("¿Cuantas filas y columnas tiene la matriz cuadrada? ")
	n = int(input())
	return n

def leer_matriz_nreales(matr, n):
	f = int()
	c = int()
	print("A continuación ingrese uno a uno los valores numerico reales a almacenar en la matriz de ",n," Filas y ",n," Columnas: ")
	for f in range(n):
		for c in range(n):
			print("Valor de la Fila ",f," y Columna ",c," => ")
			matr[f][c] = float(input())

def mostrar_matriz_nreales(matr, n):
	f = int()
	c = int()
	print("Los valores almacenados en la matriz de numeros reales de ",n," Filas y ",n," Columnas son: ")
	for f in range(n):
		for c in range(n):
			print("Valor de la Fila ",f," y Columna ",c," => ")
			print(matr[f][c])

def sumpromdp(matr, n):
	sdp = float()
	f = int()
	sdp = 0.0
	f = 0
	while f<n:
		sdp = sdp+matr[f][f]
		f = f+1
	promdp = sdp/n
	return sdp,promdp

def sumpromds(matr, n):
	sds = float()
	f = int()
	c = int()
	sds = 0.0
	f = 0
	c = n-1
	while f<n:
		sds = sds + matr[f][c]
		f = f+1
		c = c-1
	promds = sds/n
	return sds,promds

def mostrar_sum_promdps(sumadp, sumads, promdp, promds):
	print("La suma de los elementos ubicados en la diagonal principal de la matriz es: ",sumadp)
	print("El promedio de los elementos ubicados en la diagonal principal de la matriz es: ",promdp)
	print("La suma de los elementos ubicados en la diagonal secundaria de la matriz es: ",sumads)
	print("El promedio de los elementos ubicados en la diagonal secundaria de la matriz es: ",promds)

if __name__ == '__main__':
	n = int()
	i = int()
	matr = []
	sumadp = float()
	sumads = float()
	promdp = float()
	promds = float()
	n = leer_cant_fc()
	for i in range(n):
	    matr.append([0]*n)
	leer_matriz_nreales(matr, n)
	mostrar_matriz_nreales(matr,n)
	sumadp, promdp = sumpromdp(matr,n)
	sumads, promds = sumpromds(matr,n)
	mostrar_sum_promdps(sumadp,sumads,promdp,promds)

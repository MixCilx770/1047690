
# Hacer un programa que le permita a un usuario ingresar un grupo de numeros enteros, almacenarlos en una matriz de nxm y  mostrarlos.
# El numero de filas n, lo ingresa el usuario, lo mismo que el numero de columnas m. Calcular y mostrar el promedio de filas y el promedio de columnas.
# Autor: Jose Alirio Barragan Sanchez
# Version: 2.0

def leer_nfil_mcol():
	n = int()
	m = int()
	print("Ingrese la cantidad de filas: ")
	n = int(input())
	print("Ingrese el numero de columnas: ")
	m = int(input())
	return n,m

def leer_matriz_ent(matn, n, m):
	f = int()
	c = int()
	print("A continuacion ingrese uno a uno los valores enteros a almacenar en la matriz de ",n," Filas y ",m," Columnas: ")
	for f in range(n):
		for c in range(m):
			print("Valor de la Fila ",f," y Columna ",c," => ")
			matn[f][c] = int(input())

def mostrar_matriz_ent(matn, n, m):
	f = int()
	c = int()
	print("Los valores almacenados en la matriz de ",n," Filas y ",m," Columnas son: ")
	for f in range(n):		
		for c in range(m):
			print("Valor de la Fila ",f," y Columna ",c," => ")
			print(matn[f][c])

def promedio_filas(matn, n, m, pf):
	sumaf = int()
	f = int()
	c = int()
	for f in range(n):
		sumaf = 0
		for c in range(m):
			sumaf = sumaf+matn[f][c]
		pf[f] = sumaf/m

def promedio_columnas(matn, n, m, pc):
	sumac = int()
	f = int()
	c = int()
	for c in range(m):
		sumac = 0
		for f in range(n):
			sumac = sumac+matn[f][c]
		pc[c] = sumac/n

def mostrar_promfc(pf, pc, n, m):
	i = int()
	print("Los promedios de las filas de la matriz son: ")
	for i in range(n):
		print("El promedio de la fila ",i," es: ",pf[i])
	print("Los promedios de las columnas de la matriz son: ")
	for i in range(m):
		print("El promedio de la columna ",i," es: ",pc[i])

if __name__ == '__main__':
    n = int()
    m = int()
    i = int()
    j = int()
    matn = []
    pf = []
    pc = []
    n,m = leer_nfil_mcol()
    for i in range(n):
	    matn.append([0]*m) 
    leer_matriz_ent(matn,n,m)
    mostrar_matriz_ent(matn,n,m)
    for i in range(n):
        pf.append(0)
    for i in range(m):
        pc.append(0)
    promedio_filas(matn, n, m, pf)
    promedio_columnas(matn, n, m, pc)
    mostrar_promfc(pf, pc, n, m)
    
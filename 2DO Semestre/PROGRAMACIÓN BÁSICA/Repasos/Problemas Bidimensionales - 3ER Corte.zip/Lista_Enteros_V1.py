# Programa que le permita a un usuario ingresar uno a uno n numeros enteros, almacenarlos en una lista
# (Vector) y luego visualizar todo el contenido de dicha lista.
# Autor: Jose Alirio Barragan Sanchez
# Version: 1.0

def leer_cant_nume():
	m = int()
	print("¿Cuantos numeros enteros va a ingresar? ")
	m = int(input())
	return m

def leer_enteros(nume, n):
	i = int()
	print("A continuación ingrese uno a uno los ",n," numeros enteros: ")
	for i in range(n):
		print("Ingrese el numero: ",(i+1))
		nume[i] = int(input())

def mostrar_enteros(nume, n):
	i = int()
	print("A continuación se muestran los ",n," numeros enteros ingresados ")
	for i in range(0,n,1):
		print(nume[i])

def sum_prom(nume, n):
	i = int()
	suman = int()
	promedion = float()
	suman = 0
	for i in range(n):
		suman = suman + int(nume[i])
	promedion = suman / n
	return suman, promedion

def mostrar_suma_prom(suman, promedion, n):
    print("La suma de los ",n," numeros enteros es: ", suman)
    print("El promedio de los ",n," numeros enteros es: ", promedion)

def buscar_numero(numero : int, nume, n : int, pos):
	encont = bool
	i = int()
	contador = int()
	contador = 0	
	for i in range(n):		
		if numero == int(nume[i]):
			pos[contador] = i
			contador = contador + 1	
	if contador != 0:
		encont = True
	else:
		encont = False
	return encont, contador

def buscar_mayor_menor(nume, n):
	i = int()
	may = int()
	men = int()
	may = nume[0]
	men = nume[0]
	for i in range(0,n,1):		
		if int(nume[i] > may):
			may = nume[i]
		if int(nume[i] < men):
			men = nume[i]
	return may, men

def ordenar_lis_num(nume, n):
	i = int()
	j = int()
	aux = int()
	for i in range(n):
		for j in range(i+1,n):
			if nume[i] > nume[j]:
				aux = nume[i]
				nume[i] = nume[j]
				nume[j] = aux

if __name__ == '__main__':
	n = int()
	i = int()
	sn  = int()
	cont = int()
	numero = int()
	mayor = int()
	menor = int()
	p = float()
	encontrado = bool()
	n = leer_cant_nume()
	nume = [int() for i in range(n)]
	pos = [int() for i in range(n)]
	leer_enteros(nume,n)
	mostrar_enteros(nume,n)
	sn, p = sum_prom(nume, n)
	mostrar_suma_prom(sn, p, n)
	numero = int(input("Ingrese el valor de numero entero a buscar: "))
	encontrado, cont = buscar_numero(numero, nume, n, pos)
	if encontrado == True:
		print("El numero ingresado: ",str(numero)," se encontro ",str(cont)," veces y esta situado en las posiciones: ")
		for i in range(cont):
			print(pos[i])
	else:
			print("El numero ingresado: ",str(numero)," No se encontro ")
	mayor, menor = buscar_mayor_menor(nume, n)
	print("El numero mayor de la lista es: ",str(mayor))
	print("El numero menor de la lista es: ",str(menor))
	ordenar_lis_num(nume, n)
	mostrar_enteros(nume,n)







# Programa que ingresados aleatoriamente un numero determinado de numeros naturales por el usuario,
# identifica cuantos de esos numeros son multiplos de 5, calcula y muesta la suma y el promedio de esos numeros
# natrurales mutiplos de 5.
# Autor: José Alirio Barragán Sánchez
#  Versión: 0.2

def leer_n():
    n1 = int()
    n1 = 0
    while n1 <= 0:
        print("Ingrese el valor del numero natural siguiente: ")
        n1 = int(input())
        if n1 < 1:
            print("ERROR!! Ingresar solo numeros naturales, a partir de 1. Ingresar numero natural nuevamente")
    return n1

def leer_siga():
    print("¿Desea ingresar otro numero natural S (Si) / N (No)?: ")
    siga = input()
    if siga != 's' and siga != 'S' and siga != 'n' and siga != 'N':
        print("ERROR!! Ingresar solo s o S, o n o N, S para continuar o N para terminar ")
    return siga

def calprome(cm5,sumam5):
    promediom5 = float()
    promediom5  = sumam5 / cm5
    return promediom5

def mostrar_res(i,cm5,sumam5,promediom5):
    print("Se ingresaron en total " + str(i) + " numeros naturales")
    print("Se ingresaron en total " + str(cm5) + " multiplos de 5.")
    print("La suma de los multiplos de 5 es: " + str(sumam5))
    print("El promedio de los multiplos de 5 es: " + str(promediom5))


if __name__ == '__main__':
    siga = str() 
    i = int()
    cm5 = int()
    n = int()
    sumam5 = float()
    promediom5 = float()
    siga = 's'
    cm5  = 0
    i  = 0
    sumam5 = 0
    while siga == 's' or siga == 'S':
        n = leer_n()
        if n % 5 == 0:
            cm5 = cm5 + 1
            sumam5 = sumam5 + n
        i  = i + 1
        siga = 'k'
        while siga != 's' and siga != 'S' and siga != 'n' and siga != 'N':
            siga = leer_siga()
    promediom5 = calprome(cm5,sumam5)
    mostrar_res(i,cm5,sumam5,promediom5)
# Programa que le permita al usuario ingresar uno a uno un numero indeterminado de 
# numeros naturales, calcule y muestre la suma y promedio de todos los numeros ingresados,
# ademas almacene y muestre en una lista aparte los numeros naturales multiplos de 5, cuantos
# son multiplos de 5, la suma y el promedio de estos.
# Autor: José Alirio Barragán Sánchez
# Versión: 1.0
def leer_continuar():
	t = str()
	while True: # no hay 'repetir' en python
		print("¿Desea ingresar un nuevo numero natural S = Si / N = No? ")
		t = input()
		if t !="s" and t !="S" and t !="n" and t !="N":
			print("ERROR !!!, Solo digitar S o s o N o n, responda de nuevo")
		if t=="s" or t=="S" or t=="n" or t=="N": break
	return t

def leer_numnat(numnat1):
	cn = int()
	i = int()
	tec = str()
	tec = "s"
	i = 0
	print("A continuación ingrese uno a uno los numeros naturales, a partir de 1: ")
	while tec=="s" or tec=="S":
		while True:# no hay 'repetir' en python
			print("Ingrese el numero natural: ",(i+1))
			numnat1[i] = int(input())
			if numnat1[i]<=0:
				print("ERROR !!!, Solo numeros naturales a partir de 1, ingrese de nuevo el numero")
			if numnat1[i]>0: break
		i = i+1
		tec = leer_continuar()
	cn = i
	return cn

def calcular_sum_nat(numnat1, mult5, ctn):
	cm5 = int()
	i = int()
	j = int()
	sumat = int()
	j = 0
	sumat = 0
	print("Los numeros naturales ingresados son: ")
	for i in range(ctn):
		print(numnat1[i])
		if numnat1[i]%5==0:
			mult5[j] = numnat1[i]
			j = j+1
		sumat = sumat+numnat1[i]
	cm5 = j
	return cm5, sumat

def calcular_promnat(sumat, ctn):
	pt = float()
	pt = sumat/ctn
	return pt

def calcular_sum5_prom5(mult5, ctm5):
	i = int()
	p5 = float()
	suma5 = int()
	suma5 = 0
	print("Los numeros naturales multiplos de 5 son: ")
	for i in range(ctm5):
		print(mult5[i])
		suma5 = suma5+mult5[i]
	if ctm5!=0:
		p5 = suma5/ctm5
	else:
		print("No se encontraron numeros naturales multiplos de 5 !!!")
		p5 = 0
	return suma5, p5

def mostrar_resul(ctn, sumat, promediot, ctm5, suma5, promedio5):
	print("La cantidad de numeros naturales ingresados es: ",ctn)
	print("La suma de todos los numeros naturales ingresados es: ",sumat)
	print("El promedio total de los numeros naturales ingresados es: ",promediot)
	print("La cantidad de numeros naturales multiplos de 5 encontrados es: ",ctm5)
	print("La suma de los numeros naturales multiplos de 5 es: ",suma5)
	print("El promedio de los numeros naturales multiplos de 5 es: ",promedio5)

if __name__ == '__main__':
	numnat = int()
	mult5 = int()
	ctn = int()
	sumat = int()
	ctm5 = int()
	suma5 = int()
	i = int()
	promediot = float()
	promedio5 = float()
	numnat = [int() for i in range(100)]
	mult5 = [int() for i in range(100)]
	ctn = leer_numnat(numnat)
	ctm5, sumat = calcular_sum_nat(numnat,mult5,ctn)
	promediot = calcular_promnat(sumat,ctn)
	suma5, promedio5 = calcular_sum5_prom5(mult5, ctm5)
	mostrar_resul(ctn,sumat,promediot,ctm5,suma5,promedio5)


# Programa que lee el nombre de una persona dado por el usuario y le presenta un saludo de bienvenida.
# Autor: José Alirio Barragán Sánchez
# Versión: 3.0
# Procedimiento que lee el nombre de la persona y lo retorna bajo el paramtro por referemcia nomb.
def leer_nombre(nomb):
	# Se envia al usuario un mensaje solicitandoles el nombre
	print("Ingrese su nombre: ")
	# Se captura el nombre del usuario que ingrese por teclado
	nomb = input() # Se termina el procedimiento leer_nombre()
	return nomb

# Procedimiento que recibe el nombre de usuario a mostrar y el mensaje a presentar
def mostrar_mens_nombre(nomb, mensaje):
	# Presentamos al usuario el mensaje generado
	print(nomb,mensaje)
	# Se termina el procedimiento mostrar_mens_nombre()

# Inicio programa del saludo
if __name__ == '__main__':
	# Programa que envia un saludo de Bienvenida por pantalla
	# Se define la variables nombre y mensaje de tipo cadena para almacenar el nombre del estudiante y el mensaje a generar
	nombre = str()
	mensaje = str()
	# Se hace el llamado al procedimiento que se encargara de leer un nombre digitado por el usuario
	nombre = leer_nombre(nombre)
	# Se genera el mensaje que se mostrara
	mensaje = " Bienvenido a Programación Básica"
	# Se llama al procemiento encargado de mostrar el nombre de una persona acompa�ado de un mensaje de bienvenida.
	mostrar_mens_nombre(nombre,mensaje)
	# Finalización del algoritmo


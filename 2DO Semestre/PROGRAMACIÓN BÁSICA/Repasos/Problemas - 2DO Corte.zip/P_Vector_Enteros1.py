# Programa que le solicita a un usuario 3 numeros enteros, los almacena en un vector representado en una lista
# y despues muestra el contenido de dicho vector.
# Autor: José Alirio Barragán Sánchez
# Verisión: 1.0
a =[]
tam = int()
tam = 3
n = int()
for i in range(tam):
    print("Ingrese un numero entero: ")
    n = int(input())
    a.append(n)
print("Los tres numeros ingresados y almacenados son: ")
for i in range(tam):
    print("Numero entero: ",(i+1))
    print(int(a[i]))

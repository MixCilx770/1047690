# Programa que le permita a un usuario ingresar uno a uno n numeros enteros, almacenarlos en una lista
# (Vector) y luego visualizar todo el contenido de dicha lista.
# Autor: José Alirio Barragán Sánchez
# Versión: 1.0

def leer_cant_nume():
	m = int()
	print("¿Cuantos numeros enteros va a ingresar? ")
	m = int(input())
	return m

def leer_enteros(nume, n):
	i = int()
	print("A continuación ingrese uno a uno los ",n," numeros enteros: ")
	for i in range(n):
		print("Ingrese el numero: ",(i+1))
		nume[i] = input()

def mostrar_enteros(nume, n):
	i = int()
	print("A continuación se muestran los ",n," numeros enteros ingresados ")
	for i in range(n):
		print(nume[i])

def sum_prom(nume, n):
	i = int()
	suman = int()
	promedion = float()
	suman = 0
	for i in range(n):
		suman = suman + int(nume[i])
	promedion = suman / n
	return suman, promedion

if __name__ == '__main__':
	n = int()
	i = int()
	sn  = int()
	p = float()
	n = leer_cant_nume()
	nume = [int() for i in range(n)]
	leer_enteros(nume,n)
	mostrar_enteros(nume,n)
	sn, p = sum_prom(nume, n)
	print("La suma de los ",n," numeros enteros es: ", sn)
	print("El promedio de los ",n," numeros enteros es: ", p)
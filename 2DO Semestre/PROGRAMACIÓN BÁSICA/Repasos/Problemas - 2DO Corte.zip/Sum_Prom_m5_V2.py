# Programa que ingresados aleatoriamente un numero determinado de numeros naturales por el usuario,
# identifica cuantos de esos numeros son multiplos de 5, calcula y muesta la suma y el promedio de esos numeros
# natrurales mutiplos de 5.
# Autor: José Alirio Barragán Sánchez
# Versión: 0.3
def leer_num_nat():
	nn = int()
	n1 = int()
	while True:# no hay 'repetir' en python
		print("Ingrese el valor del numero natural siguiente: ")
		nn = int(input())
		if nn<1:
			print("ERROR!! Ingresar solo numeros naturales, a partir de 1. Ingresar numero natural nuevamente")
		if nn>=1: break
	n1 = nn
	return n1

def con_sum_m5(i, n, cm5, sumam5):
	j = int()
	if n%5==0:
		cm5[0] = cm5[0]+1
		sumam5[0] = sumam5[0]+n
	i = i+1
	j = i
	return j

def leer_siga():
	siga1 = str()
	tecla1 = str()
	while True:# no hay 'repetir' en python
		print("Desea ingresar otro numero natural S / N?: ")
		tecla1 = input()
		if tecla1!="s" and tecla1!="S" and tecla1!="n" and tecla1!="N":
			print("ERROR!! Ingresar solo s o S, o n o N, S para continuar o N para terminar ")
		if tecla1=="s" or tecla1=="S" or tecla1=="n" or tecla1=="N": break
	siga1 = tecla1
	return siga1

def promediarm5(cm5, sumam5):
	promediom5_1 = float()
	promediomult5 = float()
	if cm5!=0:
		promediomult5 = sumam5[0]/cm5[0]
	else:
		promediomult5 = 0
	promediom5_1 = promediomult5
	return promediom5_1

def mostrar_resul(i, cm5, sumam5, promediom5):
	print("Se ingresaron en total ",i," numeros naturales")
	print("Se ingresaron en total ",cm5," multiplos de 5.")
	print("La suma de los multiplos de 5 es: ",sumam5)
	print("El promedio de los multiplos de 5 es: ",promediom5)

if __name__ == '__main__':
	siga = str()
	i = int()
	#i= [0]
	n = int()
	cm5 = [0]
	sumam5 = [0]
	promediom5 = float()
	siga = "s"
	#cm5 = 0
	i = 0
	sumam5[0] = 0
	cm5[0] = 0
	while siga=="s" or siga=="S":
		n = leer_num_nat()
		i = con_sum_m5(i,n,cm5,sumam5)
		siga = leer_siga()
	promediom5 = promediarm5(cm5,sumam5)
	mostrar_resul(i,cm5,sumam5,promediom5)


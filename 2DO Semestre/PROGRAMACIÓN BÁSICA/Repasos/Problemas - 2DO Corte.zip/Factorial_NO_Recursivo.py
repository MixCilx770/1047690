# Programa que dado un numero entero positivo por el usuario calcule y muestre el factorial de dicho numero.
# Autor: José Alirio Barragán Sánchez
# Versión: 1.0
def leer_n():
    n1 = int()
    print("Ingrese el valor del entero positivo al cual se la calculara el factorial: ")
    n1 = int(input())
    return n1

def factorial(num):
    f = int()
    f = 1
    if num == 0:
        f = 1        
    else:
        while num > 0:
            f = num * f
            num = num - 1
    return f

def mostrar_factorialn(num,fac):
    print("El numero entero positivo ingresado es: ",num)
    print("El factorial del numero entero ingresado es: ",fac)

if __name__ == '__main__':
    n = int()
    fact = int()
    n = leer_n()
    fact = factorial(n)
    mostrar_factorialn(n,fact)
def leer_n():
    n1 = int()
    print("Ingrese el valor del entero positivo a partir del cual se iniciara la cuenta regresiva: ")
    n1 = int(input())
    return n1

def Cuenta_reg(num):
    while num > 0:
        print(num)
        num = num - 1
    print(num)
    print("Cuenta regresiva finalizada !!!")

if __name__ == '__main__':
    n = int()
    n = leer_n()
    Cuenta_reg(n)
# Programa que le solicita a un usuario 3 numeros enteros, los almacena en un vector representado en una lista
# y despues muestra el contenido de dicho vector.
# Autor: José Alirio Barragán Sánchez
# Verisión: 2.0
n = int(input("ingrese el tamaño de la lista de numeros: "))
l = [None]*(n)
for i in range(0,n,1):
    print("Ingrese el numero: ",(i+1))
    l[i] = int(input())
print("Los numeros enteros ingresados son: ")
for i in range(0,n,1):
    print(l[i])
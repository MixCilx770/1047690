CREATE DATABASE IF NOT EXISTS BDatos_Universidad
  DEFAULT CHARACTER SET utf8mb4;
USE BDatos_Universidad;

# =============================================
# Tabla de Sede
# =============================================
CREATE TABLE Sede (
  ID_Sede INT UNSIGNED AUTO_INCREMENT,
  Nombre_Sede VARCHAR(50),
  Direccion VARCHAR(100),
  PRIMARY KEY (ID_Sede)
);
INSERT INTO Sede (Nombre_Sede, Direccion) 
VALUES
('Barranquilla','Transv 110 #45 - 94'),
('Ibagué','Cra 50 #30 - 21'),
('Medellín - Prado Centro','Cll 59 #50 - 92'),
('Cali','Cra 45 #20 - 18');

# =============================================
# Tabla de Usuario
# =============================================
CREATE TABLE Usuario (
  Cedula CHAR(10),
  Nombre_Completo VARCHAR(100),
  Direccion VARCHAR(100),
  Telefono VARCHAR(15),
  ID_Sede INT UNSIGNED,
  PRIMARY KEY (Cedula),
  FOREIGN KEY (ID_Sede) REFERENCES Sede(ID_Sede)
);
INSERT INTO Usuario (Cedula, Nombre_Completo, Direccion, Telefono, ID_Sede) 
VALUES
('1032428520','Alexander Lopez Cifuentes Estrada','Cra 45 #32 - 150','3105748721',1),
('1005874213','Mariana Torres Restrepo','Cll 12 #47 - 89','3017854498',2),
('1013248756','Juan Pablo Castaño Montoya','Cra 21 #65 - 200','3179945588',1),
('1029856741','Valentina Osorio Betancur','Transv 34 #20 - 75','3204478912',3),
('1002458796','Sebastian Arango Jaramillo','Cll 50 #10 - 33','3157789045',2),
('1000543780','Alejandro Cifuentes Bentancur','Cll 87 #45 - 20','3004507771',4);

# =============================================
# Tabla de Estudiante
# =============================================
CREATE TABLE Estudiante (
  Cedula_Estudiante CHAR(10),
  Carrera VARCHAR(60),
  Semestre TINYINT UNSIGNED,
  Fecha_Registro DATE,
  PRIMARY KEY (Cedula_Estudiante),
  FOREIGN KEY (Cedula_Estudiante) REFERENCES Usuario(Cedula)
);
INSERT INTO Estudiante (Cedula_Estudiante, Carrera, Semestre, Fecha_Registro)
VALUES
('1034875002', 'Ingeniería de Software', 2, '2017-08-25'),
('1012578944', 'Administración de Empresas', 4, '2018-02-10'),
('1023457812', 'Ingeniería Industrial', 6, '2019-09-18'),
('1009874523', 'Contaduría Pública', 1, '2020-01-12'),
('1032258741', 'Trabajo Social', 3, '2017-11-30'),
('1028745699', 'Psicología', 5, '2018-06-22'),
('1019945820', 'Medicina Veterinaria', 7, '2019-03-05');

# =============================================
# Tabla de Profesor
# =============================================
CREATE TABLE Profesor (
  Cedula_Profesor CHAR(10),
  Residencia VARCHAR(60),
  Titulo_Academico VARCHAR(80),
  Fecha_Registro DATE,
  PRIMARY KEY (Cedula_Profesor),
  FOREIGN KEY (Cedula_Profesor) REFERENCES Usuario(Cedula)
);
INSERT INTO Profesor (Cedula_Profesor, Residencia, Titulo_Academico, Fecha_Registro) 
VALUES
('1032428520','Bello','Auxiliar de Enfermería','2023-01-30'),
('1005874213','Medellín','Magíster en Educación','2022-08-15'),
('1013248756','Envigado','Doctorado en Ciencias Sociales','2021-05-10'),
('1029856741','Itagüí','Licenciado en Matemáticas','2023-02-12'),
('1002458796','Rionegro','Especialista en Seguridad Informática','2020-11-08'),
('1000543780','Sabaneta','Profesional en Ingeniería de Sistemas','2019-09-25');

# =============================================
# Tabla de Empleado
# =============================================
CREATE TABLE Empleado (
  Cedula_Empleado CHAR(10),
  Rol VARCHAR(50),
  Fecha_Registro DATE,
  PRIMARY KEY (Cedula_Empleado),
  FOREIGN KEY (Cedula_Empleado) REFERENCES Usuario(Cedula)
);
INSERT INTO Empleado (Cedula_Empleado, Rol, Fecha_Registro) 
VALUES
('1032428520', 'Bibliotecario', '2020-11-12'),    
('1005874213', 'Coordinador Académico', '2019-06-28'),  
('1013248756', 'Auxiliar Administrativo', '2022-01-15'),  
('1029856741', 'Técnico de Sistemas', '2023-04-10'),    
('1002458796', 'Gestor Documental', '2021-09-03'),    
('1000543780', 'Recepcionista', '2020-02-25');

# =============================================
# Tabla de Libro
# =============================================
CREATE TABLE Libro (
  ISBN CHAR(13),
  Titulo VARCHAR(150),
  Autor VARCHAR(100),
  Editorial VARCHAR(80),
  Edicion SMALLINT UNSIGNED,
  Anio_Edicion YEAR(4),
  Paginas SMALLINT UNSIGNED,
  Disponibilidad BOOL,
  PRIMARY KEY (ISBN)
);
INSERT INTO Libro (ISBN, Titulo, Autor, Editorial, Edicion, Anio_Edicion, Paginas, Disponibilidad) 
VALUES
('9782407620351','Las Almas Perdidas en la Oscuridad','Oscar Rodriguez Orejuela','Unión Satelite',1,2004,347,0),
('9783161484100','La Sombra del Amanecer','Valentina Osorio Betancur','Editorial Aurora',2,2010,289,1),
('9789587622314','Ecos del Pasado','Juan Pablo Castaño','Libros Andinos',1,2015,412,1),
('9789581204515','Memorias de un Caminante','Mariana Torres Restrepo','Editorial Horizonte',3,2012,198,0),
('9786071607428','El Último Guardián','Sebastian Arango Jaramillo','Pluma Dorada',1,2018,523,1);

# =============================================
# Tabla de Prestamo_Libro
# =============================================
CREATE TABLE Prestamo_Libro (
  ID_Prestamo INT UNSIGNED AUTO_INCREMENT,
  ISBN CHAR(13),
  Cedula_Usuario CHAR(10),
  Fecha_Prestamo DATE,
  Fecha_inicio DATE,
  Fecha_Final DATE,
  PRIMARY KEY (ID_Prestamo),
  FOREIGN KEY (ISBN) REFERENCES Libro(ISBN),
  FOREIGN KEY (Cedula_Usuario) REFERENCES Usuario(Cedula)
);
INSERT INTO Prestamo_Libro (ISBN, Cedula_Usuario, Fecha_Prestamo, Fecha_inicio, Fecha_Final) 
VALUES
('9782407620351','1032428520','2023-01-10','2023-01-10','2023-01-20'),
('9783161484100','1005874213','2023-02-05','2023-02-06','2023-02-15'),
('9789587622314','1013248756','2023-03-12','2023-03-12','2023-03-22');

# =============================================
# Tabla de Sala_Estudio
# =============================================
CREATE TABLE Sala_Estudio (
  ID_Sala INT UNSIGNED AUTO_INCREMENT,
  Nombre_Sala VARCHAR(50),
  Estado_Disponibilidad ENUM('Disponible','Ocupada'),
  PRIMARY KEY (ID_Sala)
);

INSERT INTO Sala_Estudio (Nombre_Sala, Estado_Disponibilidad) 
VALUES
('Lara Monilla','Disponible'),
('Sala Sigma','Ocupada'),
('Sala Robledo 2','Disponible'),
('Sala Estudio Central','Ocupada'),
('Sala Innovación Alfa','Disponible');

# =============================================
# Tabla de Prestamo_Sala
# =============================================
CREATE TABLE Prestamo_Sala (
  ID_Reserva INT UNSIGNED AUTO_INCREMENT,
  ID_Sala INT UNSIGNED,
  Cedula_Usuario CHAR(10),
  Fecha_Reserva DATE,
  Hora_Inicio TIME,
  Hora_Final TIME,
  PRIMARY KEY (ID_Reserva),
  FOREIGN KEY (ID_Sala) REFERENCES Sala_Estudio(ID_Sala),
  FOREIGN KEY (Cedula_Usuario) REFERENCES Usuario(Cedula)
);

INSERT INTO Prestamo_Sala (ID_Sala, Cedula_Usuario, Fecha_Reserva, Hora_Inicio, Hora_Final)
 VALUES
(1, '1032428520', '2024-09-16', '18:40:00', '21:30:00'),
(2, '1005874213', '2024-05-10', '14:00:00', '16:00:00'),
(3, '1013248756', '2024-03-22', '08:30:00', '10:00:00'),
(1, '1029856741', '2024-07-18', '09:45:00', '11:15:00'),
(4, '1002458796', '2024-11-01', '13:00:00', '15:30:00'),
(2, '1000543780', '2024-01-29', '17:20:00', '19:00:00');

# =============================================
# Tabla de BDatos_Revista
# =============================================
CREATE TABLE BDatos_Revista (
  ID_BDatos INT UNSIGNED AUTO_INCREMENT,
  Nombre_BDatos VARCHAR(50),
  Fecha_Inicio_Membresia DATE,
  Fecha_Final_Membresia DATE,
  PRIMARY KEY (ID_BDatos)
);

INSERT INTO BDatos_Revista (Nombre_BDatos, Fecha_Inicio_Membresia, Fecha_Final_Membresia) 
VALUES
('Cálculo','2025-02-16','2025-06-14'),
('Ingeniería y Desarrollo','2024-08-01','2025-08-01'),
('Revista de Tecnología Digital','2023-11-10','2024-11-10'),
('Ciencia y Sociedad','2024-05-20','2025-05-20');

# =============================================
# Tabla de Articulo_Revista
# =============================================
CREATE TABLE Articulo_Revista (
  ID_Articulo INT UNSIGNED AUTO_INCREMENT,
  Titulo_Articulo VARCHAR(150),
  Autores VARCHAR(150),
  Nombre_Revista VARCHAR(100),
  ID_BDatos INT UNSIGNED,
  Volumen TINYINT UNSIGNED,
  Fecha_Publicacion DATE,
  PRIMARY KEY (ID_Articulo),
  FOREIGN KEY (ID_BDatos) REFERENCES BDatos_Revista(ID_BDatos)
);
INSERT INTO Articulo_Revista (Titulo_Articulo,Autores,Nombre_Revista,ID_BDatos,Volumen,Fecha_Publicacion) 
VALUES
('Modelos Predictivos en Ciberseguridad','Oscar R. Orejuela','Cálculo',1,12,'2024-05-14'),
('Análisis de Amenazas en Redes Universitarias','Mariana Torres','Ingeniería y Desarrollo',2,7,'2023-11-28'),
('Optimización de Algoritmos de Búsqueda','Juan P. Castaño','Revista de Tecnología Digital',3,3,'2024-01-15'),
('Impacto del Machine Learning en IoT','Valentina Osorio','Ciencia y Sociedad',4,2,'2022-09-10'),
('Nuevas Tendencias en Bases de Datos','Sebastián Arango','Cálculo',1,15,'2024-06-01'),
('Ciberataques en Entornos Académicos','Carlos Vélez','Ingeniería y Desarrollo',2,9,'2023-03-22');

# =============================================
# Tabla de Consulta_Articulo
# =============================================
CREATE TABLE Consulta_Articulo (
  ID_Consulta INT UNSIGNED AUTO_INCREMENT,
  ID_Articulo INT UNSIGNED,
  Cedula_Usuario CHAR(10),
  Fecha_Consulta DATE,
  PRIMARY KEY (ID_Consulta),
  FOREIGN KEY (ID_Articulo) REFERENCES Articulo_Revista(ID_Articulo),
  FOREIGN KEY (Cedula_Usuario) REFERENCES Usuario(Cedula)
);
INSERT INTO Consulta_Articulo (ID_Articulo, Cedula_Usuario, Fecha_Consulta) 
VALUES
(1, '1032428520', '2023-03-08'), 
(2, '1005874213', '2022-11-30'), 
(3, '1013248756', '2024-02-14'),
(4, '1029856741', '2023-07-19'),
(5, '1002458796', '2024-08-05'),
(6, '1000543780', '2023-09-22');


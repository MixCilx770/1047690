class Producto:
    def __init__ (self, nombre, precio, cantidad):
        self.nombre = nombre
        self.precio = precio
        self.cantidad = cantidad
        
    
    def calcular_total(self):
        return self.precio * self.cantidad
    
    def mostrar_info(self):
        print ("\n --- INFORMACIÓN DEL PRODUCTO ---")
        print (f"El Nombre del Producto Es: {self.nombre}\nEl Precio del Producto Es: ${self.precio:,.0f}\nLa Cantidad del Producto Es: {self.cantidad}".replace(",", "."))
        print (f"El Valor Total Es: ${self.calcular_total():,.0f}".replace(",", "."))
        
P1 = Producto ("Arroz", 4200, 5)
P1.mostrar_info()
class Empleado:
    def __init__ (self, nombre, salario):
        self.nombre = nombre
        self.salario = salario
    
    def mostrar_info(self):
        print("\n --- INFORMACIÓN DEL EMPLEADO ---")
        print(f"El Nombre del Empleado Es: {self.nombre}\nEl Salario del Empleado Es: ${self.salario:,.0f}".replace(",", "."))
        
class Junior(Empleado):
    def mostrar_info(self):
        print("\n --- INFORMACIÓN DEL JUNIOR ---")
        print(f"El Nombre del Junior Es: {self.nombre}\nEl Salario del Junior Es: ${self.salario:,.0f}".replace(",", "."))

class Senior(Empleado):
    def mostrar_info(self):
        print("\n --- INFORMACIÓN DEL SENIOR ---")
        print(f"El Nombre del Senior Es: {self.nombre}\nEl Salario del Senior Es: ${self.salario:,.0f}".replace(",", "."))      
          
E1 = Empleado("Miguel", 4100000)
J1 = Junior ("Samuel", 2500000)
S1 = Senior ("Peña", 7700000)

E1.mostrar_info()
J1.mostrar_info()
S1.mostrar_info()
# --- CONSULTAS ---
# --- 1° --- 
SELECT * FROM Clientes;
# --- 2° --- 
SELECT Nombre
FROM Clientes;
# --- 3° --- 
SELECT DISTINCT Ciudad
FROM Clientes;
# --- 4° --- 
SELECT Nombre, Edad
FROM Clientes
WHERE Edad > 25;
# --- 5° --- 
SELECT Nombre, Edad
FROM Clientes
ORDER BY Edad DESC;
# --- 6° --- 
SELECT Nombre, Ciudad, Edad
FROM Clientes
WHERE Ciudad = 'Medellín' AND Edad > 20;
# --- 7° --- 
SELECT Nombre, Ciudad
FROM Clientes
WHERE Ciudad = 'Bogota' OR Ciudad = 'Cali';
# --- 8° --- 
SELECT Nombre, Ciudad
FROM Clientes
WHERE NOT Ciudad = 'Medellín'
ORDER BY Ciudad;
# --- 9° --- 
SELECT Producto, Valor
FROM Pedidos
WHERE Valor > 500
ORDER BY Valor ASC;
# --- 10° --- 
SELECT C.Nombre, P.Producto
FROM Pedidos P
INNER JOIN Clientes C ON C.ID_Cliente = P.ID_Cliente;
# --- 11° --- 
SELECT C.Nombre, C.Ciudad, P.Valor
FROM Pedidos P
INNER JOIN Clientes C ON C.ID_Cliente = P.ID_Cliente
ORDER BY Valor DESC;
# --- 12° --- 
SELECT C.Nombre, P.Producto
FROM Pedidos P
RIGHT JOIN Clientes C ON C.ID_Cliente = P.ID_Cliente;
# --- 13° --- 
SELECT C.Nombre, P.Producto
FROM Pedidos P 
LEFT JOIN Clientes C ON C.ID_Cliente = P.ID_Cliente;
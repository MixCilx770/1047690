Funcion Mt1 <- Leer_Metros_Vm (VMD Por Referencia)
	Definir Mt, Mt1 Como Real;
	Escribir "Ingrese la Cantidad de Metros de Tela Comprados: ";
	Leer Mt;
	Escribir "Ingrese El Valor de Cada Metro de Tela En d�lares: ";
	Leer VMD;
	Mt1 <- Mt;	
FinFuncion

SubProceso Calculo_Valores (Mt, VMD, TCD Por Referencia, TCPCIVA Por Referencia, TCPSIVA Por Referencia, VIVA Por Referencia)
	Definir vdp, pIVA Como Real;
	VDP <- 4100;
	PIVA <- 0.19; 
	TCD <- Mt * VMD;
    TCPSIVA <- TCD * VDP;
    VIVA <- TCPSIVA * PIVA;
    TCPCIVA <- TCPSIVA + VIVA;
FinSubProceso

SubProceso Mostrar_Resultados (TCD Por Valor, TCPSIVA Por Valor, VIVA Por Valor, TCPCIVA Por Valor)
	Escribir "El Total de la Compra En d�lares Es: ", TCD;
    Escribir "El Total de la Compra En Pesos ($) Sin IVA Es: ", TCPSIVA;
    Escribir "El Valor del IVA En Pesos ($) Es: ", VIVA;
    Escribir "El Total de la Compra En Pesos ($) Con IVA Es: ", TCPCIVA;
FinSubProceso


Funcion Presupuesto <- Verificar_Presupuesto (TCPCIVA)
	Definir Presupuesto Como Logico;
	Si TCPCIVA <= 2800000 Entonces
		Presupuesto <- Verdadero;
		Escribir "El Costo Est� dentro del Presupuesto";
	SiNo
		Presupuesto <- Falso;
		Escribir "El Costo No Est� dentro del Presupuesto";
	FinSi
FinFuncion

Proceso Compra_Telas
	Definir MT, VMD, d, TCD, TCPSIVA, VIVA, TCPCIVA Como Real;
	Definir Presupuesto Como Logico;
	VMD <- 0;
	d <- 0;
	Mt <- Leer_Metros_Vm (VMD);
	Calculo_Valores(Mt, VMD, TCD, TCPCIVA, TCPSIVA, VIVA);
	Mostrar_Resultados(TCD, TCPSIVA, VIVA, TCPCIVA);
	Presupuesto <- Verificar_Presupuesto (TCPCIVA);
FinProceso

Funcion N <- Soli_Tem (X)
	definir N, N1 Como Real;
	Escribir "Ingrese Cu�ntas Temperaturas desea Ingresar: ";
	Leer N1;
	N <- N1;
FinFuncion

SubProceso Val_TEM (N Por Referencia, Lis Por Referencia)
	definir C Como Real;
	Para C <- 0 hasta (N - 1) Con Paso 1 Hacer
		Escribir "Ingrese la ", c + 1," Temperatura: ";
		Leer Lis(C);
	FinPara
FinSubProceso

SubProceso Val_Gen (N Por Referencia, Lis Por Referencia)
	definir C Como Real;
	Escribir "La Lista General de los Valores Ingresados Es: ";
	Para C <- 0 hasta (N - 1) Con Paso 1 hacer;
		Escribir Lis(C);
	FinPara
FinFuncion

SubProceso Ord_Lis (N, Lis Por Referencia)
	definir i, j Como Entero;
	definir Temp Como Real;
	Para i <- 0 hasta N - 2 Hacer
		Para j <- 0 hasta N - 2 - i Hacer
			Si Lis(j) > Lis(j + 1) Entonces
				Temp <- Lis(j);
				Lis(j) <- Lis(j + 1);
				Lis(j + 1) <- Temp;
			FinSi
		FinPara
	FinPara
FinSubProceso

SubProceso Most_Lis (N, Lis)
    definir i Como Entero;
    Para i <- 0 hasta N - 1 Hacer
        Escribir "Las Temperaturas Ordenadas Son ", i + 1, ": ", Lis(i);
    FinPara
FinSubProceso


Funcion Max <- Max_Min (N Por Referencia, Lis Por Referencia, Min Por Referencia)
	definir Max, C Como Entero;
	Max <- Lis(0);
	Min <- Lis(0);
	Para C <- 1 hasta (N - 1) Con Paso 1 Hacer
		Si Lis(C) > Max Entonces
			Maxx <- Lis(C);
			Si Lis(C) < Min Entonces 
				Min <- Lis(C);
			FinSi
		FinSi 
		
	FinPara
FinFuncion


Funcion Suma <- SumaMAT (N Por Referencia, Lis Por Referencia)
	definir SumaNAT, Suma, C Como Real;
	SumaNAT <- 0;
	Para C <- 0 hasta (N - 1) Con Paso 1 Hacer
		SumaNAT <- SumaNAT + Lis(C);
	FinPara
	Suma <- SumaNAT;
FinFuncion

Funcion Promedio <- PromedioMAT (N Por Referencia, Lis Por Referencia, Suma Por Valor)
	definir Promedio, PromedioM, C Como Real;
	PromedioM <- Suma/N;
	Promedio <- PromedioM;
FinFuncion

Funcion Superior <- Sup_inf (N Por Referencia, Lis Por Referencia, Promedio Por Referencia, inferior Por Referencia)
	Definir Superior, C Como Entero;
	Superior <- 0;
	inferior <- 0;
	Para C <- 0 hasta (n - 1) Con Paso 1 Hacer
		Si Lis(C) > Promedio Entonces 
			superior <- superior + 1;
		SiNo 
			Si Lis(C) < Promedio Entonces
				inferior <- inferior + 1;
			FinSi
		FinSi
	FinPara
FinFuncion

Proceso Val_Gen_TEMP
	definir N, X, Suma, Max, Min, Superior, inferior Como Entero;
	definir Promedio Como Real;
	definir Lis Como Entero;
	X <- 0;
	N <- Soli_TEM(X);
	dimension Lis(N);
	Val_TEM(N, Lis);
	Val_Gen(N, Lis);
	Ord_Lis(N, Lis);
	Most_Lis(N, Lis);
	Max <- Max_Min(N, Lis, Min);
	Escribir "La Temperatura Maxima Registrada Fue de: ",Max;
	Escribir "La Temperatura Minima Registrada Fue de: ",Min;
	Suma <- SumaMAT (N, Lis);
	Escribir "Esta Es la Suma Total de las Temperaturas: ",Suma;
	Promedio <- PromedioMAT(N, Lis, Suma);
	Escribir "El Promedio de los Valores Encontrados Es: ",Promedio;
	Superior <- Sup_inf(n, Lis, Promedio, inferior);
	Escribir "Las Temperaturas Registradas Superiores Al Promedio Son: ",Superior;
	Escribir "Las Temperaturas Registradas inferiores Al Promedio Son: ",inferior;
FinProceso

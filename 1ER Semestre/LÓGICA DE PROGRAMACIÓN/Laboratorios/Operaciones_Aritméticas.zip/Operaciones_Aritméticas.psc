//Programa que Calcule Problemas Aritm�ticos
//Autores: Miguel Larrea, Samuel Mosquera, Johan Lopez
//Versi�n: 1.0
Proceso Operaciones_Aritm�ticas //Inicia El Programa
	Definir Valor_1, Valor_2, Suma, Resta, Resta_2, Multiplicaci�n, Divisi�n, Divisi�n_2 Como Real; //Definimos las Variables Como Reales
	Escribir "Ingrese El Primer Valor Num�rico: " ; //Pedimos Al Usuario El Primer Valor Num�rico
	Leer Valor_1; //La Entrega del Usuario del Primer Valor Num�rico
	Escribir "Ingrese El Segundo Valor Num�rico: " ; //Pedimos Al Usuario El Segundo Valor Num�rico
	Leer Valor_2; //La Entrega del Usuario del Segundo Valor Num�rico
	Suma <- (Valor_1+Valor_2); //Almacenamos la Operaci�n Aritm�tica de Suma
	Resta <- (Valor_1-Valor_2); //Almacenamos la Operaci�n Aritm�tica de la Primera Resta
	Resta_2 <- (Valor_2-Valor_1); //Almacenamos la Operaci�n Aritm�tica de la Segunda Resta
	Multiplicaci�n <- (Valor_1*Valor_2); //Almacenamos la Operaci�n Aritm�tica de la Multiplicaci�n
	Divisi�n <- (Valor_1/Valor_2); //Almacenamos la Operaci�n Aritm�tica de la Primera Divisi�n
	Divisi�n_2 <- (Valor_2/Valor_1); //Almacenamos la Operaci�n Aritm�tica de la Segunda Divisi�n
	Escribir "El Valor Calculado de la Suma Es: ", Suma; //Entrega del Valor Calculado de la Suma
	Escribir "El Valor Calculado de la Resta Es: ", Resta; //Entrega del Valor Calculado de la Primera Resta
	Escribir "El Valor Calculado de la Resta Hacia Su N�mero Contrario Es: ", Resta_2; //Entrega del Valor Calculado de la Segunda Resta
	Escribir "El Valor Calculado de la Multiplicaci�n Es: ", Multiplicaci�n; //Entrega del Valor Calculado de la Multiplicaci�n
	Escribir "El Valor Calculado de la Divisi�n Es: ", Divisi�n; //Entrega del Valor Calculado de la Primera Divisi�n
	Escribir "El Valor Calculado de la Divisi�n Hacia Su N�mero Contrario Es: ", Divisi�n_2; //Entrega del Valor Calculado de la Segunda Divisi�n
FinProceso 

//Programa que Permita Mostrar Separaci�n, Sumas Y Promedios de los Numeros Pares, impares Y Naturales.
//Miguel Larrea, Samuel Mosquera, Johan Lopez
//Version 1.0
Proceso Num_Naturales //inicia El Programa
		//Definimos las Variables Como Entero, Real Y L�gico
		Definir N, Con_Par, Con_impar, Suma_Par, Suma_impar, Suma_Gener, Suma_ParEimpar, i, X Como Entero;
		Definir Prom_Par, Prom_impar, Prom_Gener Como Real;
		Escribir "Ingrese la Cantidad deseada de Numeros Naturales: "; //le Solicitamos Al Usuario que ingrese El Numero Natural que desea Usar.
		leer N; //Se Lee Y Se Almacena El Numero Natural deseado E ingresado Por El Usuario.
		
		// Mostrar Todos los Numeros del 1 Al N, Separados por Comas Y Con Punto Final.
		Escribir "La Cantidad de N�meros Generados Son:";
		Para i <- 1 Hasta N Con Paso 1 Hacer 
			Si i < N Entonces
				Escribir i, ", ", Sin Saltar;
			SiNo
				Escribir i, ".", Sin Saltar;  
			FinSi
		FinPara
		
		//Le Asignamos Valores A las Variables Contables.
		Con_Par <- 0;
		Con_impar <- 0;
		Suma_Par <- 0;
		Suma_impar <- 0;
		
		//Usamos El Ciclo "Para" para hacer los Respectivos Procesos Matematicos Solicitados.
		Para X <- 1 Hasta N hacer
			Si X Mod 2 == 0 Entonces
				Con_Par <- Con_Par + 1;  //Realizamos El Proceso Matematico Para Encontrar los Pares
				Suma_Par <- Suma_Par + X; //Realizamos El Proceso Matematico Para Calcular la Suma de los Pares Encontrados.
				Prom_Par <- Suma_Par / Con_Par; //Realizamos El Proceso Matematico Para Encontrar El Promedio de los Numeros Pares.
				
			SiNo
				Con_impar <- Con_impar + 1; //Realizamos El Proceso Matematico Para Encontrar los impares
				Suma_impar <- Suma_impar + X; //Realizamos El Proceso Matematico Para Calcular la Suma de los impares Encontrados.
				Prom_impar <- Suma_impar / Con_impar; //Realizamos El Proceso Matematico Para Encontrar El Promedio de los Numeros impares.
			FinSi
		FinPara
		
		//Asignacion de procesos matematicos para encontrar suma y promedio de los numeros pares e impares generados.
		Suma_Gener <- Suma_Par + Suma_impar; //Realizamos El Proceso Matematico Para Calcular la Cantidad de las Sumas de los Numeros Pares E impares. 
		Suma_ParEimpar <- Con_Par + Con_impar; //Realizamos El Proceso Matematico Para Calcular la Cantidad de los Numeros pares E impares.
		Prom_Gener <- Suma_Gener / Suma_ParEimpar; //Realizamos El Proceso Matematico Para Calcular El Promedio de Todos los Numeros Pares E impares.
		
		//Mostramos Al Usuario Cada Uno de los Calculos hechos En Todo El Proceso.
		Escribir "";
		Escribir " La Cantidad de N�meros Pares Encontrados Es: ", Con_Par;
		Escribir "La Cantidad de N�meros impares Encontrados Es: ", con_impar;
		Escribir "La Suma de los N�meros Pares Es: ", Suma_Par;
		Escribir "La Suma de los N�meros impares Es: ", Suma_impar; 
		Escribir "El Promedio de los N�meros Pares Es: ", Prom_Par;
		Escribir "El Promedio de los N�meros impares Es: ", Prom_impar;
		Escribir "La Suma General de los N�meros Pares E impares Es: ", Suma_Gener;
		Escribir "El Promedio General de los N�meros Pares E impares Es: ", Prom_Gener;
		
FinProceso //Finaliza El Programa.

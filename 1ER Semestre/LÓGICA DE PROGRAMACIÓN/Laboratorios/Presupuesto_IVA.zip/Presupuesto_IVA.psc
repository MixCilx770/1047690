//Programa que Permita indicar El Metraje Y Hacer Saber Si Est� dentro O No del Presupuesto
//Autor: Miguel Larrea, Samuel Mosquera, Johan Lopez
//Versi�n 1.0
Proceso Presupuesto_IVA // Inicia El Programa
	Definir MT, VMD, VP, PIVA, TCD, TCPSIVA, VIVA, TCPCIVA, PM Como Real; //Definimos las Variables Como Reales
	VDP <- 4100; //Valor de Un D�lar A Pesos
	PIVA <- 0.19; // Se Asigna El Porcentaje del IVA
	PM <- 2800000; //Se Define El Presupuesto M�ximo Permitido En Pesos
	Escribir "Ingrese la Cantidad de Metros de Tela Comprados: "; //Pedimos Al Usuario la Cantidad de Metros de Tela Comprados
	Leer MT; //Se lee Y Se Almacena El Valor de Metros de Tela indicados Por El Usuario
	Escribir "Ingrese El Valor de Cada Metro de Tela En D�lares: "; //Pedimos Al Usuario El Valor de Cada Metro de Tela En D�lares
	Leer VMD; //Se lee Y Se Almacena El Valor del Metro de Tela En D�lares
	TCD <- MT * VMD; //Calcular El Total de la Compra En D�lares
	TCPSIVA <- TCD * VDP; //Calcular El Total de la Compra A Pesos Sin IVA
	VIVA <- TCPSIVA * PIVA; //Calcular El Total del Valor del IVA A Pagar En Pesos
	TCPCIVA <- TCPSIVA * VIVA; //Calcular El Total de la Compra A Pesos Con IVA
	Escribir "Total de la Compra En D�lares:$ ", TCD; //Entrega del Total de la Compra En D�lares
	Escribir "Total de la Compra En Pesos Sin Aplicar IVA:$ ", TCPSIVA; //Entrega de la Compra En Pesos Sin Aplicar IVA
	Escribir "Valor del IVA A Pagar En Pesos:$ ", VIVA; //Entrega del IVA A Pagar En Pesos
	Escribir "Total de la Compra En Pesos Con IVA:$ ", TCPCIVA; //Entrega del la Compra En Pesos Con IVA
	Si TCPCIVA >= PM Entonces //Verificamos Si Est� dentro del Presupuesto
		Escribir "El Costo Est� dentro del Presupuesto."; //Le decimos Al Usuario que El Costo Si Est� dentro del Presupuesto
	SiNo //Verificamos Si No Est� dentro del Presupuesto
		Escribir "El Costo No Est� dentro del Presupuesto."; //Le decimos Al Usuario que El Costo No Est� dentro del Presupuesto
	FinSi //Finaliza la Verificaci�n
FinProceso //Finaliza El Programa

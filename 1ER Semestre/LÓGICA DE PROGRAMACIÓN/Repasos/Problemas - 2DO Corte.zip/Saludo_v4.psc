// Programa que lee el nombre de una persona dado por el usuario y le presenta un saludo de bienvenida.
// Autor: Jos� Alirio Barrag�n S�nchez
// Versi�n: 4.0
Funcion nob <- leer_nombre() // Funcion que lee el nombre de la persona y lo retorna bajo el paramtro por referemcia nomb.
	Definir nomb, nob Como Cadena;
	Escribir "Ingrese su nombre: "; // Se envia al usuario un mensaje solicitandoles el nombre
	Leer nomb; // Se captura el nombre del usuario que ingrese por teclado
	nob <- nomb;
FinFuncion // Se termina el procedimiento leer_nombre()

SubProceso mostrar_mens_nombre(nomb Por Valor, mensaje Por Valor) // Procedimiento que recibe el nombre de usuario a mostrar y el mensaje a presentar
	Escribir nomb, mensaje; // Presentamos al usuario el mensaje generado	
FinSubProceso // Se termina el procedimiento mostrar_mens_nombre()

Proceso Saludo_V3 // Inicio programa del saludo
	// Programa que envia un saludo de Bienvenida por pantalla
	Definir nombre, mensaje Como cadena; // Se define la variables nombre y mensaje de tipo cadena para almacenar el nombre del estudiante y el mensaje a generar
	nombre <- leer_nombre(); // Se hace el llamado al procedimiento que se encargara de leer un nombre digitado por el usuario
	mensaje <- " Bienvenido a L�gica de Programaci�n"; // Se genera el mensaje que se mostrara
	mostrar_mens_nombre(nombre,mensaje); // Se llama al procemiento encargado de mostrar el nombre de una persona acompa�ado de un mensaje de bienvenida.	
FinProceso // Finalizaci�n del algoritmo

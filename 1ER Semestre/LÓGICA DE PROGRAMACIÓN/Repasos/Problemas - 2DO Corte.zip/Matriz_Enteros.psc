// Hacer un programa que le permita a un usuario ingresar un grupo de numeros enteros, almacenarlos en una matriz de nxm y  mostrarlos.
// El numero de filas n, lo ingresa el usuario, lo mismo que el numero de columnas m.
// Autor: Jos� Alirio Barrag�n S�nchez
// Version: 1.0

Funcion n <- leer_nfil_mcol(m Por Referencia)
	Definir n1, n Como Entero;
	Escribir "Ingrese la cantidad de filas: ";
	Leer n1;
	Escribir "Ingrese el numero de columnas: ";
	Leer m;
	n <- n1;
FinFuncion

Subproceso Leer_Matriz_Ent(matn Por Referencia, n Por Valor, m Por Valor)
	Definir f,c Como Entero;
	Escribir "A continuaci�n ingrese uno a uno los valores enteros a almacenar en la matriz de ",n," Filas y ",m," Columnas: ";
	Para f <- 0 Hasta n-1 Con paso 1 Hacer
		Para c <- 0 Hasta m-1 Con paso 1 Hacer
			Escribir "Valor de la Fila ",f," y Columna ",c," => ";
			Leer matn(f,c);
		FinPara
	FinPara
FinSubProceso

Subproceso Mostrar_Matriz_Ent(matn Por Referencia, n Por Valor, m Por Valor)
	Definir f,c Como Entero;
	Escribir "Los valores almacenados en la matriz de ",n," Filas y ",m," Columnas son: ";
	Para f <- 0 Hasta n-1 Con paso 1 Hacer
		Para c <- 0 Hasta m-1 Con paso 1 Hacer
			Escribir "Valor de la Fila ",f," y Columna ",c," => ";
			Escribir matn(f,c);
		FinPara
	FinPara
FinSubProceso

Proceso Matriz_Enteros
	Definir n,m,matn Como Entero;
	m <- 0;
	n <- leer_nfil_mcol(m);
	Dimension matn(n,m);
	Leer_Matriz_Ent(matn, n, m);
	Mostrar_Matriz_Ent(matn, n, m);
FinProceso

// programa que calcula la edad de una persona, conocido el a�o de nacimiento y determine si la persona
// esta en la mayoria de edad, es mayor de edad o es menor de edad. El programa debe mostrar el a�o de nacimiento
// de la persona, la edad calculada y el mensaje de determinaci�n sobre la edad.
// Autor: Jos� Alirio Barrag�n S�nchez
// Version: 0.2
Funcion an1 <- leer_an()
	Definir an1, anacimiento Como Entero;
	Escribir "Digite el a�o de nacimiento de la persona: ";
	Leer anacimiento;
	an1 <- anacimiento;
FinFuncion

Funcion edad1 <- calcular_edad(AA Por Valor, an1 Por Valor)
	Definir edad1, cedad Como Entero;
	cedad <- AA - an1;
	edad1 <- cedad;
FinFuncion

Subproceso analiza_edad(edad Por Valor, ME Por Valor, mensaje1 Por Referencia)
	Si edad = ME Entonces
		mensaje1 <- "est� en la mayoria de edad";		
	SiNo
		Si edad > ME Entonces
			mensaje1 <- "es mayor de edad";
		SiNo
			mensaje1 <- "es menor de edad";
		FinSi
	FinSi
FinSubProceso

Subproceso mostrar_resultados(an Por Valor, edad Por Valor, mensaje Por Valor)
	Escribir "El a�o de nacimiento ingresado es el a�o ",an;
	Escribir "La edad calculada de la persona es: ",edad," a�os";
	Escribir "La persona ", mensaje;
FinSubProceso

Algoritmo  Cal_Det_Edad
	Definir AA, ME, an, edad Como Entero;
	Definir mensaje Como Cadena;
	AA <- 2021;
	ME <- 18;
	an <- leer_an();
	edad <-  calcular_edad(AA, an);
	mensaje <- "";
	analiza_edad(edad, ME, mensaje);
	mostrar_resultados(an, edad,mensaje);	
FinAlgoritmo


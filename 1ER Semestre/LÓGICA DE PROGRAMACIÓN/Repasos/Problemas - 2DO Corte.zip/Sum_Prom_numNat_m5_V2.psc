// Programa que le permita al usuario ingresar uno a uno un numero indeterminado de 
// numeros naturales, calcule y muestre la suma y promedio de todos los numeros ingresados,
// ademas almacene y muestre en una lista aparte los numeros naturales multiplos de 5, cuantos
// son multiplos de 5, la suma y el promedio de estos. Con funcion adicional de busqueda de un numero natural en la lista de numros creada
// Autor: Jos� Alirio Barrag�n S�nchez
// Versi�n: 2.0

Funcion t <- leer_continuar()
	Definir t, t1 Como Caracter;
	Repetir
		Escribir "�Desea ingresar un nuevo numero natural S = Si / N = No? ";
		leer t1;
		Si t1 <> 's' y t1 <> 'S' y t1 <> 'n' y t1 <> 'N' Entonces
			Escribir "ERROR !!!, Solo digitar S o s o N o n, responda de nuevo";
		FinSi
	Hasta Que t1 = 's' o t1 = 'S' o t1 = 'n' o t1 = 'N'
	t <- t1;
FinFuncion

Funcion cn <- leer_numnat(numnat1 Por Referencia)
	Definir cn, i Como Entero;
	Definir tec Como Caracter;
	tec <- 's';
	i <- 0;
	Escribir "A continuaci�n ingrese uno a uno los numeros naturales, a partir de 1: ";
	Mientras tec = 's' o tec = 'S' Hacer
		Repetir
			Escribir "Ingrese el numero natural: ",(i+1);
			leer numnat1[i];
			Si numnat1[i] < 0 Entonces
				Escribir "ERROR !!!, Solo numeros naturales a partir de 1, ingrese de nuevo el numero";
			FinSi
		Hasta Que numnat1[i] > 0
		i <- i+1;
		tec <- leer_continuar();
	FinMientras
	cn <- i;
FinFuncion

Funcion cm5 <- Calcular_sum_nat(numnat1 Por Referencia, mult5 Por Referencia, sumat Por Referencia, ctn Por Valor)
	Definir cm5, i, j Como Entero;
	j <- 0;
	sumat <- 0;
	Escribir "Los numeros naturales ingresados son: ";
	Para i <- 0 Hasta ctn-1 Con Paso 1 Hacer
		Escribir numnat1[i];
		Si numnat1[i] MOD 5 = 0 Entonces
			mult5[j] <- numnat1[i];
			j <- j + 1;
		FinSi
		sumat <- sumat + numnat1[i];
	FinPara
	cm5 <- j;
FinFuncion

Funcion pnt <- Calcular_Promnat(sumat Por Valor, ctn Por Valor)
	Definir pnt, pt Como Real;
	pt <- sumat / ctn;
	pnt <- pt;
FinFuncion

Funcion pmn5 <- Calcular_Sum5_Prom5(mult5 Por Referencia, suma5 Por Referencia, ctm5 Por Valor)
	Definir i Como Entero;
	Definir p5, pmn5 Como Real;
	suma5 <- 0;
	Escribir "Los numeros naturales multiplos de 5 son: ";
	Para i <- 0 Hasta ctm5-1 Con Paso 1 Hacer
		Escribir mult5[i];
		suma5 <- suma5 +  mult5[i];
	FinPara
	Si ctm5 <> 0 Entonces
		p5 <- suma5 / ctm5;
	SiNo
		Escribir "No se encontraron numeros naturales multiplos de 5 !!!";
		p5 <- 0;
	FinSi
	pmn5 <- p5;
FinFuncion

SubAlgoritmo mostrar_resul(ctn Por Valor, sumat Por valor, promediot Por Valor, ctm5 Por valor, suma5 Por Valor, promedio5 Por Valor)
	Escribir "La cantidad de numeros naturales ingresados es: ",ctn;
	Escribir "La suma de todos los numeros naturales ingresados es: ",sumat;
	Escribir "El promedio total de los numeros naturales ingresados es: ",promediot;
	Escribir "La cantidad de numeros naturales multiplos de 5 encontrados es: ",ctm5;
	Escribir "La suma de los numeros naturales multiplos de 5 es: ",suma5;
	Escribir "El promedio de los numeros naturales multiplos de 5 es: ",promedio5;
FinSubAlgoritmo

Funcion m <- leer_numb()
	Definir m, m1 Como Entero;
	Escribir "Ingrese el numero natural a buscar en la lista de numeros: ";
	Leer m1;
	m <- m1;
FinFuncion

Funcion ec <- busqueda_Dato(numnat1 Por Referencia, ctn Por Valor, veces Por Referencia, posi Por Referencia, num Por Referencia)
	Definir ec, ec1 Como Logico;
	Definir i,j, n Como Entero;
	ec1  <- Falso;
	n  <- leer_numb();
	j <- 0;
	veces <- 0;
	Para i <- 0 Hasta  ctn-1 Con Paso 1 Hacer
		Si numnat1[i] = n Entonces
			posi[j] <- i;
			veces <- veces + 1;
			j <- j + 1;
		FinSi
	FinPara
	Si veces <> 0 Entonces
		ec1  <- Verdadero;
	FinSi
	num <- n;
	ec  <- ec1;
FinFuncion

Subproceso mostrar_resul_busqueda(posi Por Referencia, veces Por Valor, ec Por Valor, m Por Valor)
	Definir i Como Entero;
	Si ec = Verdadero Entonces
		Escribir "El numero ",m," buscado se encuentra ",veces," veces en la lista de numeros";
		Escribir "Ese numero se encuentra en las siguientes posiciones del vector principal: ";
		Para i <- 0 Hasta veces-1 Con Paso 1 Hacer
			Escribir posi[i];
		FinPara
	SiNo
		Escribir "El numero ",m," buscado NO se encuentra en la lista de numeros";
	FinSi	
FinSubProceso

Proceso Sum_Prom_numNat_m5
	Definir numnat, mult5, ctn, sumat, ctm5, suma5, veces, posi, num Como Entero;
	Definir promediot, promedio5 Como Real;
	Definir encontrado Como Logico;
	Dimension numnat(100), mult5(100), posi(100);
	encontrado <- Falso;
	veces <- 0;
	ctn <- leer_numnat(numnat);
	sumat <- 0;
	ctm5 <- Calcular_sum_nat(numnat, mult5, sumat, ctn);
	promediot <- Calcular_Promnat(sumat, ctn);
	suma5 <-	 0;
	promedio5 <- Calcular_Sum5_Prom5(mult5, suma5, ctm5);
	mostrar_resul(ctn, sumat, promediot, ctm5, suma5, promedio5);
	encontrado <- busqueda_Dato(numnat, ctn, veces, posi, num);
	mostrar_resul_busqueda(posi, veces, encontrado, m);
FinProceso

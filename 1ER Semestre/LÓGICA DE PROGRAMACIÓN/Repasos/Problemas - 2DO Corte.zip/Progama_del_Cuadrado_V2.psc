// Programa que dado el lado de un cuadrado.
// Calcula el perimetro, semiperimetro y area de dicho cuadrado.
// Y muestra por pantalla el lado, perimetro, semiperimetro y area de dicho.
// Autor: Ingeniero Jos� Alirio Barrag�n S�nchez.
// Version: 2.0

Funcion l1 <- leer_Ladoc()
	Definir l1, lado Como Real;
	Escribir "Por favor ingrese el tama�o de un lado de tu cuadrado en metros(m): "; // Se solicita al usuario del programa el valor del lado del cuadrado
	leer lado; // Se lee el valor del lado del cuadrado, capturando el dato desde el teclado
	l1 <- lado;
FinFuncion

Funcion peric <- cacular_psac(l Por Valor, sp Por Referencia, ac Por Referencia)
	Definir peric, perimetroc Como Real;
	perimetroc <- l*4; // Se calcula el valor del perimetro, aplicando la formula.
	sp <- perimetroc/2; // Se calcula el valor del semiperimetro, aplicando la formula.
	ac <- l^2; // Se calcula el valor del area, aplicando la formula.
	peric <- perimetroc;
FinFuncion

SubProceso mostrar_psac(l Por Valor, p Por Valor, sp Por Valor, ac Por Valor)
	Escribir "El valor digitado del lado del cuadrado es: ",l, " m"; // Se muestra por consola el valor del lado ingresado por el usuario.
	Escribir "el perimetro de tu cuadrado es: ", p, " m"; // Se muestra por consola el valor del perimetro calculado.
	Escribir "el semiperimetro de tu cuadrado es: ", sp, " m"; // Se muestra por consola el valor del semiperimetro calculado.
	Escribir "el area de tu cuadrado es: ", ac, " m^2"; // Se muestra por consola el valor del �rea calculada.
FinSubProceso

Proceso pspa_cuad // Se inicia el programa para los calculos del perimtro, semiperimetro y area de un cuadrado
	definir l, p, sp, ac Como Real; // Se define las variables para el lado del cuadrado, el perimetro, semiperimetro y area del cuadrado
	l <- leer_Ladoc();
	sp <- 0;
	ac <- 0;
	p <- cacular_psac(l, sp, ac);
	mostrar_psac(l, p, sp, ac);
FinProceso

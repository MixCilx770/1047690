// Programa que ingresados aleatoriamente un numero determinado de numeros naturales por el usuario,
// identifica cuantos de esos numeros son multiplos de 5, calcula y muesta la suma y el promedio de esos numeros
// natrurales mutiplos de 5.
// Autor: Jos� Alirio Barrag�n S�nchez
//  Versi�n: 0.1
Funcion n1 <- leer_num_nat(n Por Referencia)
	Definir nn,n1 Como Entero;
	Repetir
		Escribir "Ingrese el valor del numero natural siguiente: ";
		leer nn;
		Si nn < 1 Entonces
			Escribir "ERROR!! Ingresar solo numeros naturales, a partir de 1. Ingresar numero natural nuevamente";
		FinSi
	Hasta Que nn >= 1
	n1 <- nn;
FinFuncion

Funcion j <- con_sum_m5(i Por Valor, n por valor, cm5 Por Referencia, sumam5 Por Referencia)
	Definir j Como Entero;
	Si n MOD 5 = 0 Entonces
		cm5  <- cm5 + 1;
		sumam5 <- sumam5 + n;
	FinSi
	i  <- i + 1;
	j <- i;
FinFuncion

Funcion siga1 <- leer_siga()
	Definir siga1, tecla1 Como Caracter;
	Repetir
		Escribir "�Desea ingresar otro numero natural S / N?: ";
		leer tecla1;
		Si tecla1 <> 's' y tecla1 <> 'S' y tecla1 <> 'n' y tecla1 <> 'N' Entonces
			Escribir "ERROR!! Ingresar solo s o S, o n o N, S para continuar o N para terminar ";
		FinSi
	Hasta Que tecla1 = 's' o tecla1 = 'S' o tecla1 = 'n' o tecla1 = 'N'
	siga1 <- tecla1;
FinFuncion

Funcion promediom5_1 <- promediarm5(cm5 Por Valor, sumam5 Por Valor)
	Definir promediom5_1, promediomult5 Como Real;
	Si cm5 <> 0 Entonces
		promediomult5  <- sumam5 / cm5;
	SiNo
		promediomult5 <- 0;
	FinSi
	promediom5_1 <- promediomult5;
FinFuncion

SubAlgoritmo mostrar_resul(i Por Valor, cm5 Por Valor, sumam5 Por Valor, promediom5 Por Valor)
	Escribir "Se ingresaron en total ",i," numeros naturales";
	Escribir "Se ingresaron en total ",cm5," multiplos de 5.";
	Escribir "La suma de los multiplos de 5 es: ",sumam5;
	Escribir "El promedio de los multiplos de 5 es: ",promediom5;
FinSubAlgoritmo

Proceso Sum_Prom_m5
	Definir siga Como Caracter;
	Definir i, n, cm5, sumam5 Como Entero;
	Definir promediom5 Como Real;
	siga <- 's';
	cm5  <- 0;
	i  <- 0;
	sumam5 <- 0;
	Mientras siga = 's' o siga = 'S' Hacer
		n <- leer_num_nat();
		i  <- con_sum_m5(i, n, cm5, sumam5);
		siga <- leer_siga();		
	FinMientras
	promediom5 <- promediarm5(cm5,sumam5);
	mostrar_resul(i, cm5, sumam5, promediom5);
FinProceso

// Programa que permita enviarle un saludo de bienvenida a los estudiantes de L�gica de Programaci�n.
// Solicitando el nombre del estudiante.
// Version: 1.0
// Autor: Jose Alirio Barragan Sanchez
Proceso Saludo // Se inicio el programa que emitira un saludo al estudiante
	Limpiar Pantalla;
	Definir MENSAJE, nombre, salud Como Cadena; // Se define la constante de cadena para el mensaje y la variable para el nombre.
	Definir siga Como Caracter;
	MENSAJE <- ", Bienvenido a Logica de Programacion"; // Se le asigna mensaje de bienvenida a la constante  MENSAJE.
	siga  <- 's';
	Mientras siga = 's' o siga = 'S' Hacer
		Escribir "Ingrese el nombre del estudiante: "; // Se solicita al usuario el nombre del estudiante.
		Leer nombre; // Se lee mediante captura el nombre del estudiante, almacenandolo en la variable nombre
		salud <- Concatenar(nombre,MENSAJE); // Se unen el nombre y el mensaje de bienvenida y se le asignan a la variable salud.
		Escribir salud; // Se muestra el nombre con el mensaje de bienvenida.
		Repetir
			Escribir "�Desea ingresar otro nombre para saludar (Responda (s) para SI o (n) para NO)?";
			Leer siga;
			Si siga <> 'S' y siga <> 's' y siga <> 'N' y siga <> 'n' Entonces
				Escribir "La respuesta no puede ser diferente de las letras [S,s,N o n]: Ingrese de nuevo su respuesta. Enter para continuar...";
				Esperar Tecla;
				Borrar Pantalla;
			FinSi
		Hasta Que siga = 'S' o  siga = 'S' o siga = 'N' o siga = 'n'
		Borrar Pantalla;
	FinMientras	
FinProceso  // Se finaliza el programa.

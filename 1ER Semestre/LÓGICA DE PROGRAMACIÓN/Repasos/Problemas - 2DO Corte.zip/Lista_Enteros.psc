// programa que le permita a un usuario ingresar uno a uno n numeros enteros, almacenarlos en una lista
// (Vector) y luego visualizar todo el contenido de dicha lista.
// Autor: Jos� Alirio Barrag�n S�nchez
// Versi�n: 1.0

Funcion n1 <- leer_cant_nume()
	Definir n1, m Como Entero;
	Escribir "�Cuantos numeros enteros va a ingresar? ";
	Leer m;
	n1 <- m;
FinFuncion

subproceso leer_enteros(nume Por Referencia, n Por Valor)
	Definir i Como Entero;
	Escribir "A continuaci�n ingrese uno a uno los ",n," numeros enteros: ";
	Para i <- 0 Hasta n-1 Con Paso 1 Hacer
		Escribir "Ingrese el numero: ",(i+1);
		leer nume[i];
	FinPara
FinSubProceso

subproceso mostrar_enteros(nume Por Referencia, n Por Valor)
	Definir i Como Entero;
	Escribir "A continuaci�n se muestran los ",n," numeros enteros ingresados ";
	Para i <- 0 Hasta n-1 Con Paso 1 Hacer		 
		Escribir nume[i];
	FinPara
FinSubProceso

Proceso Lista_Enteros
	Definir n, nume Como Entero;
	n  <- leer_cant_nume();
	Dimension nume(n);
	leer_enteros(nume, n);
	mostrar_enteros(nume, n);
FinProceso

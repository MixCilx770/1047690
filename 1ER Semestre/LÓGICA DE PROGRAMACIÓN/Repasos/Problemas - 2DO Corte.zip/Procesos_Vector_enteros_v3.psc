
Funcion suma1 <- sumatn(n Por Referencia, tam Por Valor)
	Definir suma, suma1, i Como Entero;
	suma <- 0;
	Para i <- 0 Hasta (tam - 1) Con Paso 1 Hacer
		suma <- suma + n(i);
	FinPara
	suma1 <- suma;
FinFuncion

Funcion prom1 <- promediotn(suma Por Valor, cn Por Valor)
	Definir promedio, prom1 Como Real;	
	promedio <- suma / cn;
	prom1 <- promedio;
FinFuncion

Funcion enc1 <- Buscar_Lineal(n Por Referencia, pos Por Referencia, ce Por Referencia, nume Por Valor, tam Por Valor)
	Definir i, j Como Entero;
	Definir enc1, encon Como Logico;
	i <- 0;
	j <- 0;
	Mientras i <= (tam - 1) Hacer
		Si nume = n(i) Entonces
			ce <- ce + 1;
			pos(j) <- i;
			j <- j + 1;
		FinSi
		i <- i + 1;
	FinMientras
	Si ce = 0 Entonces
		encon <- Falso;
	SiNo
		encon <- Verdadero;
	FinSi
	enc1 <- encon;
FinFuncion

Funcion may1 <- buscar_may_men(tam Por Valor, n Por Referencia, men1 Por Referencia)
	Definir may, may1, i Como Entero;
	may <- n(0);
	i <- 0;
	Mientras i <= tam-1 Hacer
		Si n(i) > may Entonces
			may <- n(i);
		FinSi
		Si n(i) < men1 Entonces
			men1 <- n(i);
		FinSi
		i <- i + 1;
	FinMientras
	may1 <- may;
FinFuncion

SubAlgoritmo ordenar_lista(tam Por Valor, n Por Referencia)
	Definir i, j, aux Como Entero;
	Para i <- 0 Hasta tam-1 Con Paso 1 Hacer
		Para j <- i + 1 Hasta tam-1 Con Paso 1 Hacer
			Si n(i) > n(j) Entonces
				aux <- n(i);
				n(i) <- n(j);
				n(j) <- aux;
			FinSi
		FinPara
	FinPara
FinSubAlgoritmo

SubAlgoritmo Ver_maymen(may Por Valor, men Por valor)
	Escribir "El numero entero de mas valor ingresado es: ",may;
	Escribir "El numero entero de menos valor ingresado es: ", men;
FinSubAlgoritmo

SubProceso mostrar_r(n Por Referencia, suma Por Valor, promedio Por Valor, tam Por Valor)
	Definir i Como Entero;
	Escribir "La lista de numeros enteros tiene ",tam," numeros enteros, estos son: ";
	Para i <- 0 Hasta (tam - 1) Con Paso 1 Hacer
		Escribir "Valor del elemento ",(i + 1),": ",n(i);
	FinPara	
	Escribir "La suma de los numeros enteros es: ",suma;
	Escribir "El promedio de los numeros enteros es: ",promedio;
FinSubProceso

Proceso Operciones_Vector_enteros
	Definir n, pos, tam, suma, num, ce, may, men, i Como Entero;
	Definir promedio Como Real;
	Definir encontrado Como Logico;
	Escribir "�Cuantos numeros enteros va a ingresar? ";
	leer tam;
	Dimension n(tam), pos(tam);
	Para i <- 0 Hasta (tam - 1) Con Paso 1 Hacer
		Escribir "Ingrese el valor del entero: ",(i + 1);
		Leer n(i);
	FinPara
	suma <- sumatn(n, tam);
	promedio <- promediotn(suma, tam);
	mostrar_r(n, suma, promedio, tam);
	Escribir "Ingrese un valor a buscar en la lista de numeros enteros: ";
	Leer num;
	ce <- 0;
	encontrado <- Buscar_Lineal(n, pos, ce, num, tam);
	Si encontrado = Falso Entonces
		Escribir "El numero ",num," no se encuentra en la lista de numeros enteros, por lo tanto aparece ",ce," Veces";
	SiNo
		Escribir "El numero ",num," se encuentra en la lista de numeros enteros y aparece ",ce," Veces";
		Escribir "El numero buscado aparece en las siguientes posiciones de la lista de numeros enteros: ";
		i <- 0;
		Repetir
			Escribir pos(i);
			i <- i + 1;
		Hasta Que i = ce
	FinSi
	men <- n(0);
	may <- buscar_may_men(tam, n, men);
	Ver_maymen(may, men);
	ordenar_lista(tam, n);
	mostrar_r(n, suma, promedio, tam);
FinProceso

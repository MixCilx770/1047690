// Programa que ingresados dos numeros enteros realiza operaciones de suma, resta, 
// multiplicacion, division o todas y muestra los resultados de la operacion escogida
// Auotor: Jose Alirio Barragan Sanchez
// Version: 1.0
Proceso Oper_dos_num
	Definir n1, n2, s, r1, r2, m, op Como Entero;
	Definir d1, d2 Como Real;
	Definir siga Como Caracter;
	Escribir "Este programa realiza las operaciones de suma, resta, multiplicacion y division entre dos numeros enteros.";
	Repetir
		Escribir "Ingrese el primer numero entero: ";
		Leer n1;
		Escribir "Ingrese el segundo numero entero: ";
		Leer n2;
		Escribir "Menu de operaciones a relizar con el numero ",n1," y el numero ",n2;
		Repetir
			Escribir "___________MENU DE OPERACIONES________";
			Escribir "1. Sumar ambos numeros";
			Escribir "2. Restar de ",n1," el numero ",n2;
			Escribir "3. Restar de ",n2," el numero ",n1;
			Escribir "4. Multioplicar ambos numeros";
			Escribir "5. Dividir ",n1," entre ",n2;
			Escribir "6. Dividir ",n2," entre ",n1;
			Escribir "7. Ver todas las operaciones";
			Escribir "8. Salir de este MENU de operaciones";
			Repetir
				Escribir "Elija la opcion de la operacion a realizar";
				Leer op;
				Si op < 1 o op > 8 Entonces
					Escribir "ERROR, ingrese una opcion valida entre 1 y 8!!!";
				FinSi
			Hasta Que op >= 1 y op <= 8
			segun op Hacer
				1:   s <- n1 + n2;
					Escribir "La suma de ",n1," con ",n2," es: ",s;
				2:   r1 <- n1 - n2;
					Escribir "La resta de ",n1," con ",n2," es: ",r1;
				3:   r2 <- n2 - n1;
					Escribir "La resta de ",n2," con ",n1," es: ",r2;
				4:   m <- n1 * n2;
					Escribir "El producto de ",n1," con ",n2," es: ",m;
				5:   d1 <- n1 / n2;
					Escribir "La division de ",n1," con ",n2," es: ",d1;
				6:   d2 <- n2 / n1;
					Escribir "La division de ",n2," con ",n1," es: ",d2;
				7:   s <- n1 + n2;
					r1 <- n1 - n2;
					r2 <- n2 - n1;
					m <- n1 * n2;
					d1 <- n1 / n2;
					d2 <- n2 / n1;
					Escribir "La suma de ",n1," con ",n2," es: ",s;
					Escribir "La resta de ",n1," con ",n2," es: ",r1;
					Escribir "La resta de ",n2," con ",n1," es: ",r2;
					Escribir "El producto de ",n1," con ",n2," es: ",m;
					Escribir "La division de ",n1," con ",n2," es: ",d1;
					Escribir "La division de ",n2," con ",n1," es: ",d2;
				8:   Escribir "Operaciones entre ",n1," y ",n2,"FINALIZADAS";
			FinSegun
		Hasta Que  op = 8
		Repetir
			Escribir "�Desea ingresar otro par de numeros enteros diferentes S / N ?";
			Leer siga;
			Si siga = 's' y siga = 'S' y siga = 'n' y siga = 'N' Entonces
				Escribir "ERROR, la respuesta a la pregunta anterior debe ser S (s) o N (n)!!!!";
			FinSi
		Hasta Que siga = 's' o siga = 'S' o siga = 'n' o siga = 'N'
	Hasta Que siga = 'N' o siga ='n'	
FinProceso

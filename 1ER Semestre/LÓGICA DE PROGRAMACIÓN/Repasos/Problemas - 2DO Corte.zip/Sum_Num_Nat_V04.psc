// Programa que genere los numeros naturales desde un valor inicial hasta un valor final determinado por el usuario, muestre los numeros generados y muestre la suma de estos.
// Autor: Jos� Alirio Barrag�n S�nchez
// Versi�n: 0.1
Funcion vi1 <- leer_Valor_inicial() // Se inicia la funci�n que lee el valor inicial
	Definir vi1, vin Como Entero; // se declaran las variables locales de la funcion leer_Valor_inicial()
	Escribir "Ingrese el valor inicial numerico natural, a partir del cual se generaran los numeros naturales: "; // Se solicita al usuario el valor inicial para generar los numeros naturales
	Leer vin; // Se captura por teclado el valor inicial ingresado por el usario
	vi1 <- vin; // Retorna el valor inicial a partir del cual se generara los numeros naturales
FinFuncion // Finaliza funci�n que solicita al usuario el valor inicial de los nuemeros a generar

Funcion vf1 <- leer_valor_final() // Se inicia la funci�n que lee el valor final
	Definir vf1, vif Como Entero; // se declaran las variables locales de la funcion leer_Valor_final()
	Escribir "Ingrese el valor final numerico natural, hasta donde se generaran los numeros naturales: "; // Se solicita al usuario el valor final para generar los numeros naturales
	Leer vif; // Se captura por teclado el valor final ingresado por el usario
	vf1 <- vif; // Retorna el valor final hasta donde se generara los numeros naturales
FinFuncion // Finaliza funci�n que solicita al usuario el valor final de los nuemeros a generar


SubAlgoritmo generar_mos_numeros(vi Por Valor, vf Por Valor, sumanum Por Referencia) // Se inicia el procedimiento que genera los naturales y los suma
	Definir i Como Entero; // Se declaran las variables locales del procedimientoa que genera los numeros naturles.
	i <- vi; // Se inicializa el contador en el valor inicial para generar los numeros naturales	
	Escribir "Los numeros naturales generados son: "; // Se envia mensaje indicando que se mostraran a continuaci�n las lista de numeros naturales generados
	Mientras i <= vf  Hacer // Se inicia el ciclo que repetiar las instrucciones que generan y muestran los numeros naturales desde el valor inicial hasta el valor final
		Escribir i; // Se muestra por consola el numero natural generado
		sumanum <- sumanum + i; // Se alamacena en el acumulados sumanum el numero natural generado
		i <- i + 1; // Se genera el siguiente numero natural incrementando la variable contador con un paso de uno en uno
	FinMientras // Se finaliza el ciclo mientras que genera los numeros naturales
FinSubAlgoritmo // Finaliza el procedimiento de generar numeros naturales y sumarlos

SubAlgoritmo mstrar_suma(sumanum Por Valor) // Se inicia procedimiento que muestra la suma de los numeros naturales
	Escribir "La suma de los numeros naturales generados es: ", sumanum; // Se muiestra la suma total de los numeros naturales generados
FinSubAlgoritmo // Se finaliza el procedimiento que muestra la suma de los numeros naturales

Proceso Sum_Num_Nat // Seinicia el programa de generaci�n y suma de numeros naturales
	Definir vi, vf, i, sumanum Como Entero; // Se definen las variables de valor inicial, valor final, contador y suma de numeros naturales
	vi <- leer_Valor_inicial(); // se llama a lafuncion para leer el valor inicial
	vf <- leer_valor_final(); // se llama a la funcion para leer el valor final
	sumanum <- 0; // Se inicializa la variable aculmuladora que sumara los numeros naturales generados
	generar_mos_numeros(vi, vf, sumanum); // Se llama a ejecuci�n el procedimiento que genera los numeros naturales y los suma, enviandole como parametros el valor inicial, el valor final y la suma inicializadoa en CERO
	mstrar_suma(sumanum); // Se llama a ejecuci�n el procedimiento que muestra el resultado de la suma de los numeros naturales generados
FinProceso // Se fianliza el algortimo

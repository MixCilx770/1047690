
Funcion n1 <- leer_cantidad_nume()
	Definir n, n1 Como Entero;
	Repetir
		Escribir "�Cuantos numeros enteros va a ingresar? ";
		Leer n;
		Si n <= 0 Entonces
			Escribir "ERROR: La cantidad de numeros no puede ser negativa ni CERO, como minimo UNO";
		FinSi
	Hasta Que n >= 1
	n1 <- n;
FinFuncion

Subproceso ingresar_nume(n por valor, nume Por Referencia)
	Definir i Como Entero;
	Para i <- 0 Hasta (n-1) Con Paso 1 Hacer
		Escribir "Ingrese el numero entero de la lista en posicion ",i;
		Leer nume(i);
	FinPara
FinSubProceso

SubAlgoritmo Mostrar_lista(n Por Valor, nume Por Referencia)
	Definir i Como Entero;
	Escribir "La lista tiene ",n,"  numeros enteros y son: ";
	Para i <- 0 Hasta (n-1) Con Paso 1 Hacer
		Escribir nume(i);
	FinPara
FinSubAlgoritmo

Funcion may1 <- buscar_may_men(n Por Valor, nume Por Referencia, men1 Por Referencia)
	Definir may, may1, i Como Entero;
	may <- nume(0);
	men1 <- nume(0);
	i <- 0;
	Mientras i <= n-1 Hacer
		Si nume(i) > may Entonces
			may <- nume(i);
		FinSi
		Si nume(i) < men1 Entonces
			men1 <- nume(i);
		FinSi
		i <- i + 1;
	FinMientras
	may1 <- may;
FinFuncion

SubAlgoritmo Ver_maymen(may Por Valor, men Por valor)
	Escribir "El numero entero de mas valor ingresado es: ",may;
	Escribir "El numero entero de menos valor ingresado es: ", men;
FinSubAlgoritmo

SubAlgoritmo ordenar_lista(n Por Valor, nume Por Referencia)
	Definir i, j, aux Como Entero;
	Para i <- 0 Hasta n-1 Con Paso 1 Hacer
		Para j <- i + 1 Hasta n-1 Con Paso 1 Hacer
			Si nume(i) > nume(j) Entonces
				aux <- nume(i);
				nume(i) <- Nume(j);
				nume(j) <- aux;
			FinSi
		FinPara
	FinPara
FinSubAlgoritmo

Funcion enc <- buscar_num(numveces Por Referencia, listn Por Referencia, vec_pos Por Referencia, n Por Valor, numbuscar Por Valor)
	Definir enc, econt Como Logico;
	Definir i Como Entero;
	Para i <- 0 hasta n-1 Con Paso 1 Hacer
		Si numbuscar = listn(i) Entonces
			vec_pos(numveces) <- i;
			numveces <- numveces + 1;
		FinSi
	FinPara
	Si numveces <> 0 Entonces
		econt <- Verdadero;
	SiNo
		econt <- Falso;
	FinSi
	enc <- econt;
FinFuncion

Funcion prom <- cal_Sum_Prom(suma Por Referencia, n Por Valor, nume Por Referencia)
	Definir i Como Entero;
	Definir pr, prom Como Real;
	Para i <- 0 Hasta (n-1) Con Paso 1 Hacer
		suma <- suma + nume(i);
	FinPara
	pr <- suma / n;
	prom <- pr;
FinFuncion

Proceso Crear_lista_Nume
	Definir n, k, nume, may, men, numveces, numbuscar, vec_pos, suma Como Entero;
	Definir promedio Como Real;
	Definir encontrado Como Logico;
	n <- leer_cantidad_nume();
	Dimension nume(n);
	Dimension vec_pos(n);
	ingresar_nume(n, nume);
	Mostrar_lista(n, nume);
	encontrado <- Falso;
	Numveces <- 0;	
	Escribir "Ingrese el numero natural a buscar en la lista: ";
	Leer numbuscar;
	encontrado <- buscar_num(numveces, nume, vec_pos, n, numbuscar);
	Si encontrado = Verdadero Entonces
		Escribir "El numero ",numbuscar," se encontro ",numveces," veces "," y se encontro en las siguientes posiciones de la lista: ";
		Para k <- 0 hasta numveces - 1 Con Paso 1 Hacer
			Escribir vec_pos(k);			
		FinPara
	SiNo
		Escribir "El numero ",numbuscar," no se encontro en la lista por lo tanto esta ",numveces," veces";
	FinSi
	men <- 0;
	may <- buscar_may_men(n, nume, men);
	Ver_maymen(may, men);
	ordenar_lista(n, nume);
	Mostrar_lista(n, nume);
	suma <- 0;
	promedio <- cal_Sum_Prom(suma, n, nume);
	Escribir "La suma de los ",n," numeros de la lista ingresada es: ",suma;
	Escribir "El promedio de los ",n," de la lista ingresada es: ",promedio;
FinProceso

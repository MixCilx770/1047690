// Programa que que permita almacenar en una matriz de N filas y M columnas numeros 
// enteros y que muestre el contenido de valores enteros almacenados en la matriz.

Funcion n <- Leer_Cant_filasColumnas(m Por Referencia)
	Definir n1, n Como Entero;
	Escribir "Ingrese la cantidad de filas para la matriz: ";
	Leer n1;
	Escribir "Ingrese la cantidad de columnas para la matriz: ";
	Leer m;
	n <- n1;
FinFuncion 

SubAlgoritmo Leer_Val_Matriz(n Por Valor, m Por Valor, matn Por Referencia)
	Definir f, c Como Entero;
	Escribir "A continuacion ingrese uno a uno los valores enteros a almacenar en la matriz: ";
	Para f <- 0 Hasta n - 1 Con Paso 1 Hacer
		Para c <- 0 Hasta m - 1 Con Paso 1 Hacer
			Escribir "Ingrese el valor de fila => ",f," y el valor de columna => ",c;
			Leer matn(f,c);
		FinPara
	FinPara
FinSubAlgoritmo

Subproceso Mostrar_Val_Matriz(n Por Valor, m por valor, matn Por Referencia)
	Definir f, c Como Entero;
	Escribir "Los valores enteros que contiene la matriz son: ";
	Para f <- 0 Hasta n - 1 Con Paso 1 Hacer
		Escribir "Elementos enteros de la fila => ",f;
		Para c <- 0 Hasta m - 1 Con Paso 1 Hacer			
			Escribir matn(f,c);
		FinPara
	FinPara
FinSubProceso

Funcion sumamat <- sumamn(n Por Valor, m Por Valor, matn Por Referencia)
	Definir sumamat, sumam Como Real;
	Definir f,c Como Entero;
	sumam <- 0;
	Para f <- 0 Hasta n-1 Con Paso 1 Hacer
		Para c <- 0 hasta m - 1 Con Paso 1 Hacer
			sumam <- sumam + matn(f,c);
		FinPara
	FinPara
	sumamat <- sumam;
FinFuncion

Funcion promediomat <- promediom(sumamat Por Valor, n Por Valor, m por valor)
	Definir promediomat, promediome Como Real;
	promediome <- sumamat / (n * m);
	promediomat <- promediome;
FinFuncion

Funcion promediodp <- suma_promdp(n por valor, m Por Valor, matn Por Referencia, sumadp Por Referencia)
	Definir promediodp, promediodp1 Como Real;
	Definir f Como Entero;
	Si n = m Entonces
		sumadp <- 0;
		Para f <- 0 hasta n - 1 Con Paso 1 Hacer
			sumadp <- sumadp + matn(f,f);
		FinPara
		promediodp1 <- sumadp / n;
	SiNo
		Escribir "No se puede sumar y promediar los elementos de la Diagonal Principal porque la matriz no es cuadrada!!!";
		promediodp1 <- 0;
	FinSi
	promediodp <- promediodp1;
FinFuncion

Funcion promediods <- suma_promds(n por valor, m Por Valor, matn Por Referencia, sumads Por Referencia)
	Definir promediods, promediods1 Como Real;
	Definir f Como Entero;
	Si n = m Entonces
		sumads <- 0;
		Para f <- 0 hasta n - 1 Con Paso 1 Hacer
			sumads <- sumads + matn(f,m-1-f);
		FinPara
		promediods1 <- sumads / n;
	SiNo
		Escribir "No se puede sumar y promediar los elementos de la Diagonal Principal porque la matriz no es cuadrada!!!";
		promediods1 <- 0;
	FinSi
	promediods <- promediods1;
FinFuncion

Proceso Matriz_Enteros
	Definir n, m, matn Como Entero;
	Definir sumamat, promediomat, sumadp, promediodp, sumads, promediods Como Real;
	m <- 0;
	n <- Leer_cant_filasColumnas(m);
	Dimension matn(n,m);
	Escribir "La matriz tendra ",n," filas y ",m," Columnas";
	Leer_Val_Matriz(n, m, matn);
	Mostrar_Val_Matriz(n, m, matn);
	sumamat <- sumamn(n, m, matn);
	promediomat <- promediom(sumamat, n, m);
	Escribir "La suma de los elementos de la matriz de enteros de ",n," filas por ",m," columnas es: ",sumamat;
	Escribir "El promedio de los elementos de la matriz de enteros de ",n," filas por ",m," columnas es: ",promediomat;
	sumadp <- 0;
	promediodp <- suma_promdp(n, m, matn, sumadp);
	Si promediodp <> 0 Entonces
		Escribir "La suma de la Diagonal Principal es: ",sumadp," y el promedio de la Diagonal principal es: ",promediodp;
	FinSi
	sumads <- 0;
	promediods <- suma_promds(n, m, matn, sumads);
	Si promediods <> 0 Entonces
		Escribir "La suma de la Diagonal Secundaria es: ",sumads," y el promedio de la Diagonal Secundaria es: ",promediods;
	FinSi
FinProceso

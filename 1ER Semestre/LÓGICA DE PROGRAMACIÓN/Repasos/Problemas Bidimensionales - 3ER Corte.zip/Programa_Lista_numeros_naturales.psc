
Funcion n1 <- leer_cantidad_naturles()
	Definir n1, m Como Entero;
	Repetir
		Escribir "�Cuantos numeros naturales va a ingresar? ";
		Leer m;
		Si m < 1 Entonces
			Escribir "ERROR: El numero ",m," no es valido, no puede ser menor que UNO (1). Vuelva a ingresar la cantidad.";
		FinSi
	Hasta Que m >= 1	
	n1 <- m;
FinFuncion

SubAlgoritmo Leer_lista_num_nat(listn Por Referencia, n Por Valor)
	Definir i Como Entero;
	Escribir "A continuacion ingrese uno a uno los ",n," numeros naturales: ";
	Para i <- 0 hasta n-1 Con Paso 1 Hacer
		Repetir
			Escribir "Valor ",(i + 1)," = ";
			Leer listn(i);
			Si listn(i) < 1 Entonces
				Escribir "ERROR: El numero ",listn(i)," ingresado a la lista no es permitido. Solo valores a partir de UNO(1). Ingrese el valor de nuevo !!!";
			FinSi
		Hasta Que listn(i) >= 1		
	FinPara
FinSubAlgoritmo

SubProceso Mostrar_lista_num_nat(listn Por Referencia, n Por Valor)
	Definir i Como Entero;
	Escribir "A continuacion se mostrara uno a uno los",n," numeros naturales: ";
	Para i <- 0 hasta n-1 Con Paso 1 Hacer
		Escribir listn(i);
	FinPara	
FinSubProceso

Funcion su <- suma_nat(listn Por Referencia, n Por Valor)
	Definir i, su, s Como Entero;
	s <- 0;
	Para i <- 0 hasta n-1 Con Paso 1 Hacer
		s <- s + listn(i);
	FinPara
	su <- s;
FinFuncion

Funcion p <- promedio(suman Por Valor, n Por Valor)
	Definir p, pro Como Real;
	pro <- suman / n;
	p <- pro;
FinFuncion

Funcion enc <- buscar_num(numveces Por Referencia, listn Por Referencia, vec_pos Por Referencia, n Por Valor, numbuscar Por Valor)
	Definir enc, econt Como Logico;
	Definir i Como Entero;
	Para i <- 0 hasta n-1 Con Paso 1 Hacer
		Si numbuscar = listn(i) Entonces
			vec_pos(numveces) <-i;
			numveces <- numveces + 1;
		FinSi
	FinPara
	Si numveces <> 0 Entonces
		econt <- Verdadero;
	SiNo
		econt <- Falso;
	FinSi
	enc <- econt;
FinFuncion

Funcion csp <- Calcular_Valores_isp_mp(listn Por Referencia, n Por Valor, promedion Por Valor, contip Por Referencia)
	Definir i, csp, csp1 Como Entero;
	csp1 <- 0;
	Para i <- 0 hasta n-1 Con Paso 1 Hacer
		Si listn(i) >= promedion Entonces
			csp1 <- csp1 + 1;
		SiNo
			contip <- contip + 1;
		FinSi
	FinPara
	csp <- csp1;
FinFuncion

Subproceso ordenar_lista(listn Por Referencia, n Por Valor)
	Definir i, j, aux Como Entero;
	Escribir "Ordenando de menor a mayor los elementos de la lista de numeros naturales...";
	Para i <- 0 hasta n-1 Con Paso 1 Hacer
		Para j <- i + 1 hasta n-1 Con Paso 1 Hacer
			Si listn(i) < listn(j) Entonces
				aux <- listn[j];
				listn[j] <- listn[i];
				listn[i] <- aux;
			FinSi
		FinPara
	FinPara
FinSubProceso


Proceso Lista_Numeros_naturales
	Definir n, i, suman, numveces, numbuscar, listn, vec_pos, contsp, contip Como Entero;
	Definir promedion Como Real;
	Definir encontrado Como Logico;
	n <- leer_cantidad_naturles();
	Dimension listn(n), vec_pos(n);
	Leer_lista_num_nat(listn, n);
	Mostrar_lista_num_nat(listn, n);
	suman <- suma_nat(listn, n);
	Escribir "La suma de los numeros naturales ingresados es: ",suman;
	promedion <- promedio(suman, n);
	Escribir "El promedio de los numeros naturales ingreados es: ",promedion;
	encontrado <- Falso;
	Numveces <- 0;
	Repetir
		Escribir "Ingrese el numero natural a buscar en la lista: ";
		Leer numbuscar;
		Si numbuscar < 1 Entonces
			Escribir "ERRROR: El numero ",numbuscar," no es valido, no puede ser menor que UNO (1). Vuelva a ingresar la cantidad.";
		FinSi
	Hasta Que numbuscar >= 1
	encontrado <- buscar_num(numveces, listn, vec_pos, n, numbuscar);
	Si encontrado = Verdadero Entonces
		Escribir "El numero ",numbuscar," se encontro ",numveces," veces "," y se encontro en las siguientes posiciones de la lista: ";
		Para i <- 0 hasta numveces - 1 Con Paso 1 Hacer
			Escribir vec_pos(i);			
		FinPara
	SiNo
		Escribir "El numero ",numbuscar," no se encontro en la lista por lo tanto esta ",numveces," veces";
	FinSi
	contip <- 0;
	contsp <- Calcular_Valores_isp_mp(listn, n, promedion, contip);
	Escribir "La cantidad de valores iguales o superiores al promedio es: ",contsp," y la cantidad de valores inferiores al promedio es: ",contip;
	ordenar_lista(listn, n);
	Escribir "Lista de numeros naturales ORDEnADA: ";
	Mostrar_lista_num_nat(listn, n);
FinProceso

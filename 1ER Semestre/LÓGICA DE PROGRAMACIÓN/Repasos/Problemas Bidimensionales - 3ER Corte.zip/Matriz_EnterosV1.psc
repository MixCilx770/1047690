// Programa que que permita almacenar en una matriz de N filas y M columnas numeros 
// enteros y que muestre el contenido de valores enteros almacenados en la matriz.
// Autor: Jose Alirio Barragan Sanchez
// Version: 1.0

Funcion n <- Leer_Cant_filasColumnas(m Por Referencia)
	Definir n, n1 Como Entero;
	Escribir "Ingrese la cantidad de filas para la matriz: ";
	Leer n1;
	Escribir "Ingrese la cantidad de columnas para la matriz: ";
	Leer m;
	n <- n1;
FinFuncion

SubAlgoritmo Leer_Val_Matriz(n Por Valor, m Por Valor, matn Por Referencia)
	Definir f, c Como Entero;
	Escribir "A continuacion ingrese uno a uno los valores enteros a almacenar en la matriz: ";
	Para f <- 0 Hasta (n-1) Con Paso 1 Hacer
		Para c <- 0 Hasta (m-1) Con Paso 1 Hacer
			Escribir "Ingrese el valor de fila => ",f," y el valor de columna => ",c;
			Leer matn(f,c);
		FinPara		
	FinPara
FinSubAlgoritmo
	
SubProceso Mostrar_Val_Matriz(n Por Valor, m Por Valor, matn Por Referencia)
	Definir f, c Como Entero;
	Escribir "Los valores enteros que contiene la matriz son: ";
	Para f <- 0 Hasta (n-1) Con Paso 1 Hacer
		Escribir "Elementos enteros de la fila => ",f;
		Para c <- 0 Hasta (m-1) Con Paso 1 Hacer			
			Escribir matn(f,c);
		FinPara
	FinPara
FinSubProceso

Funcion sumamat <- sumamn(n Por Valor, m Por Valor, matn Por Referencia)
	Definir sumamat, sumam Como Real;
	Definir f,c Como Entero;
	sumam <- 0;
	Para f <- 0 Hasta n-1 Con Paso 1 Hacer
		Para c <- 0 hasta m - 1 Con Paso 1 Hacer
			sumam <- sumam + matn(f,c);
		FinPara
	FinPara
	sumamat <- sumam;
FinFuncion

Funcion promemat <- promedioma(sumam Por Valor, n Por Valor, m Por Valor)
	Definir promemat, promedio Como Real;
	Definir tam Como Entero;
	tam <- n * m;
	promedio <- sumam / tam;
	promemat <- promedio;
FinFuncion

Proceso Matriz_Enteros
	Definir n, m, matn Como Entero;
	Definir sumamat, promediomat Como Real;
	m <- 0;
	n <- Leer_Cant_filasColumnas(m);
	Dimension matn(n,m);
	Escribir "La matriz tendra ",n," filas y ",m," Columnas";
	Leer_Val_Matriz(n, m, matn);
	Mostrar_Val_Matriz(n, m, matn);
	sumamat <- sumamn(n, m, matn);
	promediomat <- promedioma(sumamat,n,m);
	Escribir "La suma de los elementos de la matriz de enteros de ",n," filas por ",m," columnas es: ",sumamat;
	Escribir "El promedio de los elementos de la matriz de enteros de ",n," filas por ",m," columnas es: ",promediomat;
FinProceso

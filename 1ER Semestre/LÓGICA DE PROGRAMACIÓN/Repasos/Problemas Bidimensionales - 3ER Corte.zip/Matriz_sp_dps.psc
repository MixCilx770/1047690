// Programa que permita almacenar en una matriz cuadrada de N filas y columnas numeros reales y calcule y muestre la suma y el promedio de los elementos de su diagonal principal y diagonal secundaria.
// Autor: Jos� Alirio Barrag�n S�nchez
// Versi�n: 1.0
Funcion n1 <- leer_cant_fc()
	Definir n1, n Como Entero;
	Escribir "�Cuantas filas y columnas tiene la matriz cuadrada? ";
	Leer n;
	n1 <- n;
FinFuncion

Subproceso Leer_Matriz_Nreales(matr Por Referencia, n Por Valor)
	Definir f,c Como Entero;
	Escribir "A continuaci�n ingrese uno a uno los valores numerico reales a almacenar en la matriz de ",n," Filas y ",n," Columnas: ";
	Para f <- 0 Hasta n-1 Con paso 1 Hacer
		Para c <- 0 Hasta n-1 Con paso 1 Hacer
			Escribir "Valor de la Fila ",f," y Columna ",c," => ";
			Leer matr(f,c);
		FinPara
	FinPara
FinSubProceso

Subproceso Mostrar_Matriz_Nreales(matr Por Referencia, n Por Valor)
	Definir f,c Como Entero;
	Escribir "Los valores almacenados en la matriz de numeros reales de ",n," Filas y ",n," Columnas son: ";
	Para f <- 0 Hasta n-1 Con paso 1 Hacer
		Para c <- 0 Hasta n-1 Con paso 1 Hacer
			Escribir "Valor de la Fila ",f," y Columna ",c," => ";
			Escribir matr(f,c);
		FinPara
	FinPara
FinSubProceso

Funcion sdp1 <- sumpromdp(matr Por Referencia, n Por Valor, promdp Por Referencia)
	Definir sdp, sdp1 Como Real;
	Definir f Como Entero;
	sdp <- 0.0;
	f <- 0;
	Mientras f < n Hacer
		sdp <- sdp + matr(f,f);
		f <- f + 1;
	FinMientras
	promdp <- sdp / n;
	sdp1 <- sdp;
FinFuncion

Funcion sds1 <- sumpromds(matr Por Referencia, n Por Valor, promds Por Referencia)
	Definir sds, sds1 Como Real;
	Definir f,c Como Entero;
	sds <- 0.0;
	f <- 0;
	c <- n - 1;
	Repetir		
		sds <- sds + matr(f,c);
		f <- f + 1;
		c <- c - 1;
	Hasta que f > n - 1
	promds <- sds / n;
	sds1 <- sds;
FinFuncion

SubAlgoritmo mostrar_sum_promdps(sumadp Por Valor, sumads Por Valor, promdp Por Valor, promds Por Valor)
	Escribir "La suma de los elementos ubicados en la diagonal principal de la matriz es: ",sumadp;
	Escribir "El promedio de los elementos ubicados en la diagonal principal de la matriz es: ",promdp;
	Escribir "La suma de los elementos ubicados en la diagonal secundaria de la matriz es: ",sumads;
	Escribir "El promedio de los elementos ubicados en la diagonal secundaria de la matriz es: ",promds;
FinSubAlgoritmo

Proceso Matriz_sp_dps
	Definir n Como Entero;
	Definir matr, sumadp, sumads, promdp, promds Como Real;
	n <- leer_cant_fc();
	Dimension matr(n,n);
	Leer_Matriz_Nreales(matr, n);
	Mostrar_Matriz_Nreales(matr, n);
	promdp <- 0;
	sumadp <- sumpromdp(matr, n, promdp);
	promds <- 0;
	sumads <- sumpromds(matr, n, promds);
	mostrar_sum_promdps(sumadp, sumads, promdp, promds);
FinProceso

// Hacer un programa que le permita a un usuario ingresar un grupo de numeros enteros, almacenarlos en una matriz de nxm y  mostrarlos.
// El numero de filas n, lo ingresa el usuario, lo mismo que el numero de columnas m. Calcula y muestra el promedio de filas y el promedio de columnas.
// Autor: Jos� Alirio Barrag�n S�nchez
// Version: 2.0

Funcion n <- leer_nfil_mcol(m Por Referencia)
	Definir n1, n Como Entero;
	Escribir "Ingrese la cantidad de filas: ";
	Leer n1;
	Escribir "Ingrese el numero de columnas: ";
	Leer m;
	n <- n1;
FinFuncion

Subproceso Leer_Matriz_Ent(matn Por Referencia, n Por Valor, m Por Valor)
	Definir f,c Como Entero;
	Escribir "A continuaci�n ingrese uno a uno los valores enteros a almacenar en la matriz de ",n," Filas y ",m," Columnas: ";
	Para f <- 0 Hasta n-1 Con paso 1 Hacer
		Para c <- 0 Hasta m-1 Con paso 1 Hacer
			Escribir "Valor de la Fila ",f," y Columna ",c," => ";
			Leer matn(f,c);
		FinPara
	FinPara
FinSubProceso

Subproceso Mostrar_Matriz_Ent(matn Por Referencia, n Por Valor, m Por Valor)
	Definir f,c Como Entero;
	Escribir "Los valores almacenados en la matriz de ",n," Filas y ",m," Columnas son: ";
	Para f <- 0 Hasta n-1 Con paso 1 Hacer
		Para c <- 0 Hasta m-1 Con paso 1 Hacer
			Escribir "Valor de la Fila ",f," y Columna ",c," => ";
			Escribir matn(f,c);
		FinPara
	FinPara
FinSubProceso

Subproceso Promedio_filas(matn Por Referencia, n Por Valor, m Por Valor, pf Por Referencia)
	Definir sumaf, f, c Como Entero;
	Para f <- 0 Hasta n-1 Con paso 1 Hacer
		sumaf <- 0;
		Para c <- 0 Hasta m-1 Con paso 1 Hacer
			sumaf <- sumaf + matn(f,c);
		FinPara
		pf(f) <- sumaf / m;
	FinPara
FinSubProceso

Subproceso Promedio_columnas(matn Por Referencia, n Por Valor, m Por Valor, pc Por Referencia)
	Definir sumac, f, c Como Entero;
	Para c <- 0 Hasta m-1 Con paso 1 Hacer
		sumac <- 0;
		Para f <- 0 Hasta n-1 Con paso 1 Hacer
			sumac <- sumac + matn(f,c);
		FinPara
		pc(c) <- sumac / n;
	FinPara
FinSubProceso

Subproceso mostrar_promfc(pf Por Referencia, pc Por Referencia, n Por valor, m Por valor)
	Definir i Como Real;
	Escribir "Los promedios de las filas de la matriz son: ";
	Para i <- 0 Hasta n-1 Con paso 1 Hacer
		Escribir "El promedio de la fila ",i," es: ",pf(i);
	FinPara
	Escribir "Los promedios de las columnas de la matriz son: ";
	Para i <- 0 Hasta m-1 Con paso 1 Hacer
		Escribir "El promedio de la columna ",i," es: ",pc(i);
	FinPara
FinSubProceso

Proceso Matriz_Enteros
	Definir n,m,matn Como Entero;
	Definir pf, pc Como Real;
	m <- 0;
	n <- leer_nfil_mcol(m);
	Dimension matn(n,m), pf(n), Pc(m);	
	Leer_Matriz_Ent(matn, n, m);
	Mostrar_Matriz_Ent(matn, n, m);
	Promedio_filas(matn, n, m, pf);
	Promedio_columnas(matn, n, m, pc);
	mostrar_promfc(pf, pc, n, m);
FinProceso

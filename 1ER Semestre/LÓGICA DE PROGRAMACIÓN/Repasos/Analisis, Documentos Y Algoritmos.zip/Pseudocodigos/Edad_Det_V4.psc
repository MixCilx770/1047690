// Programa que calcula la edad de una persona, conocido el a�o de nacimiento y determine si la persona
// esta en la mayoria de edad. El programa debe mostrar el a�o de nacimiento de la persona, la edad calculada y el mensaje de determinaci�n sobre la edad.
// Autor: Jose Alirio Barragan Sanchez
// Version 4.0

Algoritmo Edad_Det_V4 // Se inicia el progreama
	Definir AA, ME, an, edad Como Entero; //  Se definen las constantes AA, ME y la variables para el a�o de nacimiento y la edad de tipo numerico entero
	Definir mensaje Como cadena; 
	AA <- 2024; 
	ME <- 18;
	Escribir "Ingrese el a�o de nacimiento: ";
	Leer an;
	edad <- AA - an;
	Escribir "El a�o de nacimiento ingresado es: ",an," y la edad calculada es: ",edad," a�os";
	Si edad = ME Entonces
		mensaje <- "Esta en la mayoria de edad, puede sacar la CEDULA";
	SiNo
		Si edad > ME Entonces
			mensaje <- "La persona es mayor de edad, bebe tener CEDULA";
		SiNo
			mensaje <- "Es menor de edad todavia no puede sacar CEDULA";
		FinSi				
	FinSi
	Escribir mensaje;
FinAlgoritmo

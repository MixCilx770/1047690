/* Programa que calcula el perimetro, semiperimetro y area de un Rectangulo conociendo el Lado Largo y el Lado corto en Cms.
	Version: 1.0
	Autor: Jose Alirio Barragan Sanchez
*/

programa Rectangulo // Apertura del programa para los calculos de parametros en el Rectangulo
var // espacio de declaracion de variables
	mensaje, ll, lc, p, sp, a: numerico // Declaracion de variables del programa para: Lado Largo, Lado Corto, Perimetro, Semiperimetro y Area de tipo numerico
inicio
	cls() // Limpia la pantalla antes del primer mensaje de solicitud de datos
	imprimir ("\n", "Ingrese el valor del Lado Largo del Rectangulo en Cms: ")
	leer (ll)
	imprimir ("\n","Ingrese el valor del Lado Corto del Rectangulo en Cms: ")
	leer (lc)
	p = 2 * (ll + lc)
	sp = p / 2
	a =ll * lc
	imprimir ("\n","El valor calculado en Cms del perimetro es: ", p)
	imprimir ("\n","El valor calculado en Cms del semiperimetro es: ", sp)
	imprimir ("\n","El valor calculado en Cms2 del area es: ", a)
fin 
/* Programa que permita enviarle un saludo de bienvenida a los estudiantes de L�gica de Programaci�n.
	Solicitando el nombre del estudiante.
	Version: 1.0
	Autor: Jose Alirio Barragan Sanchez
*/

programa Saludo // Apertura del programa de saludo
var // espacio de declaracion de variables
	mensaje, nombre, salud: cadena
inicio
	mensaje = ", Bienvenidoa Logica de Programacion "
	imprimir ("\n","Ingrese el nombre del estudiante: ")
	leer (nombre)
	imprimir ("\n", nombre, mensaje)
fin 
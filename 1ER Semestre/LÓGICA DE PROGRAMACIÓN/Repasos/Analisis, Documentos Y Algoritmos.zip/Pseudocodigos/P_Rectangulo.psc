Proceso P_Rectangulo
	Definir ll, lc, p, sp, a Como Real;
	Escribir "Ingrese el valor del Lado Largo del Rectangulo en Cms: ";
	Leer ll;
	Escribir "Ingrese el valor del Lado Corto del Rectangulo en Cms: ";
	Leer lc;
	p <- 2 * (ll + lc);
	sp <- p / 2;
	a <- ll * lC;
	Escribir "El valor calculado en Cms del perimetro es: ", p;
	Escribir "El valor calculado en Cms del semiperimetro es: ", sp;
	Escribir "El valor calculado en Cms2 del area es: ", a;
FinProceso
